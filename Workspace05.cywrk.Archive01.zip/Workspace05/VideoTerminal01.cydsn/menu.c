/* ===================================================================== *
 *                                                                       *
 * Copyright (C) 2022 by Pieter Vandevoorde                              *
 *                                                                       *
 * This program is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation, either version 3 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 *                                                                       *
 * ===================================================================== *
*/
#include "project.h"
#include "terminal.h"
#include "window.h"
#include "menu.h"


Menu menu1 = { 2, 3, NULL, { "OFF", "ON" } };
Menu menu_textx = { 4, 2, NULL, { "1", "2", "3", "4" } };
Menu menu_texty = { 2, 2, NULL, { "1", "2" } };
Menu menu_scanset = { 4, 4, NULL, { "AUTO", "1", "2", "3" } };
Menu menu_cursor = { 3, 9, NULL, { "OFF", "UNDERLINE", "BLOCK" } };
Menu menu_color = { 8, 7, NULL, { "BLACK", "RED", "GREEN", "YELLOW ", "BLUE", "MAGENTA", "CYAN", "WHITE" } };
Menu menu_layout = { 5, 7, NULL, { "US", "US INTL", "Belgian", "UK INTL", "German"} };
Menu menu_charset = { 3, 12, NULL, { "UTF-8", "Win 1252", "ISO-8859-1" } };
Menu *menu_main_sub[] = { &menu1, &menu1, &menu_layout, &menu_scanset, &menu_color, &menu_color,
                          &menu_cursor, &menu_textx, &menu_texty, &menu1, &menu1, &menu_charset };
Menu menu_main = { 12, 16, &menu_main_sub, {
                        "Newline", "Auto Repeat", "Keyboard Layout", "Scanset",
                        "Foreground Color", "Background Color",
                        "Cursor", "Textsize X", "Textsize Y", "Wrap Around", 
                        "Line local", "Character Set"} };

uint8_t MenuSubItems(uint8_t sel) {
    Menu *sub_menu = menu_main_sub[sel];
    
    return sub_menu->items;
}

uint8_t MenuShowMain(Terminal *tm, uint8_t sel, uint8_t level) {
    uint8_t val, menu_w, menu_h;
    Window *win = tm->win;
    char *menu_str, *val_str;
    Menu *sub_menu;
    
    menu_w = (menu_main.item_len + 12) * win->bb_x;
    menu_h = win->bb_y * menu_main.items;
    
    ScreenFillRect(win->orig_x + 10, win->orig_y + 20, menu_w + 10, menu_h + 10, 0);
    
    ScreenDrawRect(win->orig_x + 10, win->orig_y + 20, menu_w + 10, menu_h + 10, 1);
    
    ScreenDrawVertLine(win->orig_x + 18 + menu_main.item_len * win->bb_x, win->orig_y + 23, menu_h + 4, 1);
    
    ScreenDrawRect(win->orig_x + 12, win->orig_y + 22, menu_w + 6, menu_h + 6, 1);

    for (uint8_t m = 0; m < menu_main.items; m++) {
        menu_str = menu_main.values[m];
        WindowSetCursor(tm->win, 2 * win->bb_x, 25 + win->bb_y * m);
        WindowWriteString(tm->win, menu_str, (m == sel) ? 1 : 0);
        
        WindowSetCursor(tm->win, (3 + menu_main.item_len) * win->bb_x, 25 + win->bb_y * m);
        val = tm->term_settings[m];
        sub_menu = (*menu_main.submenu)[m];
        val_str = sub_menu->values[val];
        WindowWriteString(tm->win, val_str, (level && (m == sel)) ? 1 : 0);
    }

    return menu_main.items;
}

void MenuShowSub(Terminal *tm, uint8_t sel0, uint8_t sel1, uint8_t erase, int16_t offset_x, int16_t offset_y) {
    Window *win = tm->win;
    Menu * sub_menu = menu_main_sub[sel0];
    uint8_t items = sub_menu->items;
    // offset_x = 200;
    
    // Clear everything before drawing the menu
    ScreenFillRect(win->orig_x + 8 + offset_x, win->orig_y + 20 + offset_y,
         sub_menu->item_len * win->bb_x + 10, win->bb_y * items + 10, 0);

    if (erase) return;
    
    // Draw outer border
    ScreenDrawRect(win->orig_x + 8 + offset_x, win->orig_y + 20 + offset_y,
         sub_menu->item_len * win->bb_x + 10, win->bb_y * items + 10, 1);
    
    // Draw inner border
    ScreenDrawRect(win->orig_x + 10 + offset_x, win->orig_y + 22 + offset_y,
         sub_menu->item_len * win->bb_x + 6, win->bb_y * items + 6, 1);
        
    for (uint8_t m = 0; m < sub_menu->items; m++) {
        WindowSetCursor(win, 2 * win->bb_x + offset_x, 25 + win->bb_y * m + offset_y);
        WindowWriteString(win, sub_menu->values[m], (m == sel1) ? 1 : 0);
    }

}

/* [] END OF FILE */
