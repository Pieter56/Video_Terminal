/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "terminal.h"

/*******************************************************************************
* Function Name: ucs2utf8
********************************************************************************
    *
* Summary:
*  Transforms a unicode code point to an utf-8 encoded byte string
*
* Parameters:
*  codepoint  input:  Unicode code point to convert (does not handle codepoints > 2 bytes)
*  utf8buf    output: pointer to a buffer to hold the utf8 encoded string
*
* Return:
*  length of the encoded utf-8 string
*
*******************************************************************************/
uint8_t ucs2utf8(unsigned char *utf8buf, uint16_t codepoint) {
    uint8_t num = 1;
    uint16_t temp = codepoint;
    
    if (codepoint < 128) {
        utf8buf[0] = codepoint & 0x7f;
    } else
    if (codepoint < 0x7ff) {
        utf8buf[1] = 0x80 | (temp & 0x3f);
        utf8buf[0] = 0xc0 | (temp >> 6 & 0x1f);
        num=2;
    } else {
        utf8buf[2] = 0x80 | (temp & 0x3f);
        utf8buf[1] = 0x80 | (temp >> 6 & 0x3f);
        utf8buf[0] = 0xe0 | (temp >> 12 & 0x0f);
        num=3;
    }
    
    return num;
}

/*******************************************************************************
* Function Name: utf8_2ucs
********************************************************************************
    *
* Summary:
*  Transforms an utf-8 encoded byte string into a 16 bit code point.
*  Only BMP (Plane 0) is handled.
*  This is the first step in transforming data received into a character
*  representation on screen.
*
* Parameters:
*  utf8buf   input:  pointer to a buffer to hold the encoded string to be converted.
*  codepoint output: pointer to buffer that will receive the code point.
*
* Return:
*  length of the encoded utf-8 string
*
*******************************************************************************/
uint8_t utf8_2ucs(uint16_t *codepoint, Buffer_t in_buffer) {
    uint8_t *utf8buf = in_buffer.buff;
    
    if (utf8buf[0] >= 0xf0) { // This is outside BMP (Plane 0), codepoint is > 16 bit
        *codepoint = 0x003f; // Question mark for this sequence
        return 4;
    }
    if (utf8buf[0] >= 0xe0) {
        if (in_buffer.count < 3) return 0;
        // Validate
        if (utf8buf[1] >= 0xc0 || utf8buf[2] >= 0xc0) return 0;
        *codepoint = (utf8buf[0] << 12) & 0xf000;
        *codepoint |= (utf8buf[1] << 6) & 0x00fc0;
        *codepoint |= utf8buf[2] & 0x003f;
        return 3;
    }
    if (utf8buf[0] >= 0xc0) {
        if (in_buffer.count < 2) return 0;
        if (utf8buf[1] >= 0xc0) return 0;
        *codepoint = (utf8buf[0] << 6) & 0x07c0;
        *codepoint |= utf8buf[1] & 0x03f;
        return 2;
    }
    // Normal ascii character
    if (utf8buf[0] < 0x80) {
        *codepoint = utf8buf[0];
        return 1;
    }
    // If we arrive here, we encountered a continuation character.
    // This should not have happened.
    
    return 0;
}

/* Usually characters 128 till 159 are control characters, but we use them to store characters that are appear
   on Western keyboards. The table maps the value to Unicode points. */
const uint16_t codepoint_lookup[] = {
    // 128     129     130     131     132     133     134     135     136     137     138     139     140 141    142     143
    0x20AC, 0x0000, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, 0x02C6, 0x2030, 0x0160, 0x2039, 0x0152, 0, 0x017D,      0,
    // 144     145     146     147     148     149     150     151     152     153     154     155     156 157    158     159
    0x0000, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0, 0x017E, 0x0178
};

/*******************************************************************************
* Function Name: ucs2ansi
********************************************************************************
    *
* Summary:
*  Transforms a codepoint into a ansi (Windows-1252) character.
*  Only limited codepoints can be converted.
*  We use the lookup table above to perform the conversion.
*
* Parameters:
*  codepoint input: the codepoint to be converted.
*
* Return:
*  The cp1252 character, if it exists.
*  0 if no match is found.
*
*******************************************************************************/
uint8_t ucs2ansi(uint16_t codepoint) {
    uint8_t ch = 0;
    
    if (codepoint < 128) return (uint8_t) codepoint;
    if (codepoint >= 160 && codepoint < 256) return (uint8_t) codepoint; // Latin-1 Punctuation and Symbols
    if (codepoint > 127 && codepoint < 160) return 0; // Ignore Control 1 codes
    
    for (uint8_t i = 0; i < sizeof(codepoint_lookup); i++) {
        if (codepoint == codepoint_lookup[i]) {
            ch = i + 128;
        }
    }
    return ch;
}

/*******************************************************************************
* Function Name: ansi2ucs
********************************************************************************
    *
* Summary:
*  Transforms an CP-1252 character into a codepoint.
*  We use the lookup table above to perform the conversion.
*
* Parameters:
*  ch   input:  the cp1252 character to be converted.
*
* Return:
*  codepoint value
*
*******************************************************************************/
uint16_t ansi2ucs(uint8_t ch) {
    if (ch < 128 || ch >= 160) return (uint16_t)ch;
    return codepoint_lookup[ch - 128];
}

/* [] END OF FILE */
