/* ===================================================================== *
 *                                                                       *
 * Copyright (C) 2022 by Pieter Vandevoorde                              *
 *                                                                       *
 * This program is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation, either version 3 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 *                                                                       *
 * ===================================================================== *
*/
#include "project.h"
#include "stdint.h"
#include "keyboard.h"
//#include "KeyboardLayout.h"
extern char tohex[];

// Keycode translation from scanset 1 to usb scanset
const uint8_t scanset1_to_usb[] = {
 /*  0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F */
    50, 41, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 45, 46, 42, 43, // 0x
    20, 26,  8, 21, 23, 28, 24, 12, 18, 19, 47, 48, 40,224,  4, 22, // 1x
     7,  9, 10, 11, 13, 14, 15, 51, 52, 53,225, 49, 29, 27,  6, 25, // 2x
     5, 17, 16, 54, 55, 56,229, 85,226, 44, 57, 58, 59, 60, 61, 62, // 3x
    63, 64, 65, 66, 67, 83, 71, 95, 96, 97, 86, 92, 93, 94, 87, 89, // 4x
    90, 91, 98, 99,154,  0,100, 68, 69                              // 5x
};

// Keycode translation from scanset 2 to usb scanset
const uint8_t scanset2_to_usb[] = {
 /*  0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F */
    50, 66,  0, 62, 60, 58, 59, 69,  0, 67, 65, 63, 61, 43, 53,  0,  // 0x
     0,226,225,  9,224, 20, 30,  0,  0,  0, 29, 22,  4, 26, 31,  0,  // 1x
     0,  6, 27,  7,  8, 33, 32,  0,  0, 44, 25,  9, 23, 21, 34,  0,  // 2x
     0, 17,  5, 11, 10, 28, 35,  0,  0,  0, 16, 13, 24, 36, 37,  0,  // 3x
     0, 54, 14, 12, 18, 39, 38,  0,  0, 55, 56, 15, 51, 19, 45,  0,  // 4x
     0,  0, 52,  0, 47, 46,  0,  0, 57,229, 40, 48,  0, 49,  0,  0,  // 5x
     0,100,  0,  0,  0,  0, 42,  0,  0, 89,  0, 92, 95,  0,  0,  0,  // 6x
    98, 99, 90, 93, 94, 96, 41, 83, 68, 87, 91, 86, 85, 97, 71,  0,  // 7x
     0,  0,  0, 64,154,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  // 8x
};

// Keycode translation from scanset 3 to usb scanset
const uint8_t scanset3_to_usb[] = {
 /*  0   1   2   3   4   5   6   7   8   9   A   B   C   D   E   F */
    50,  0,  0,  0,  0,  0,  0, 58, 41,  0,  0,  0,  0, 43, 53, 59,  // 0x
     0,224,225,100, 57, 20, 30, 60,  0,226, 29, 22,  4, 26, 31, 61,  // 1x
     0,  6, 27,  7,  8, 33, 32, 62,  0, 44, 25,  9, 23, 21, 34, 63,  // 2x
     0, 17,  5, 11, 10, 28, 35, 64,  0,230, 16, 13, 24, 36, 37, 65,  // 3x
     0, 54, 14, 12, 18, 39, 38, 66,  0, 55, 56, 15, 51, 19, 45, 67,  // 4x
     0,  0, 52,  0, 47, 46, 68, 70,228,229, 40, 48, 49,  0, 69, 71,  // 5x
    81, 80, 72, 82, 76, 77, 42, 73,  0, 89, 79, 92, 95, 78, 74, 75,  // 6x
    98, 99, 90, 93, 94, 96, 83, 84,  0, 88, 91,  0, 87, 97, 85,  0,  // 7x
     0,  0,  0,  0, 86,  0,  0,  0,  0,  0,  0,227,231,  0,  0,  0,  // 8x
};

/*
 *  The scancode received from the keyboard is first translated in USB code (+ modifiers)
 *  This code has to be translated in the correct character for serial transmission.
 *  Depending on the keyboard layout, the USB code can represent a different character.
 */


const uint8_t NUM_pad[] = { // USB codes 84 to 99 (NUM lock active)
    '/', '*', '-', '+', '\n', '1' ,'2', '3', '4', '5', '6', '7', '8', '9', '0', '.'
};

/* Should we use unicode tables ? */

/*
 * The index in the tables is the USB code + an offset depending on the modifier keys.
 * the return is a value that can be used to transmit the resulting character.
 * Characters in the range 128-160 are to be taken from the CP1252 code page.
 */

const uint8_t Keyboard_US[] = {
    // no shift
      0,   0,   0,   0, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', //  0 - 15
    'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', // 16 - 31
    '3', '4', '5', '6', '7', '8', '9', '0',  13,  27, 127,   9, ' ', '-', '=', '[', // 32 - 47
    ']',  92,   0, ';',  39,  96, ',', '.', '/',  92,   0,   0,   0,   0,   0,   0, // 48 - 63
    // shift
      0,   0,   0,   0, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
    'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '@',
    '#', '$', '%', '^', '&', '*', '(', ')',  13,  27, 127,   9, ' ', '_', '+', '{',
    '}', '|',   0, ':', '"', '~', '<', '>', '?', '|',   0,   0,   0,   0,   0,   0,
    // alt
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0, 128,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 147,
    148,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
    // alt - shift
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0, 128,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 147,
    148,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
};

const uint8_t Keyboard_US_INTL[] = { // Adds many characters through the use of ALT and SHIFT-ALT
    // no shift
      0,   0,   0,   0, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', //  0 - 15
    'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2',
    '3', '4', '5', '6', '7', '8', '9', '0',  13,  27, 127,'\t', ' ', '-', '=', '[',
    ']',  92,   0, ';',  39,  96, ',', '.', '/',  92,   0,   0,   0,   0,   0,   0, // 48 - 63
    // shift
      0,   0,   0,   0, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', // 64 - 79
    'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '@', // 80 - 95
    '#', '$', '%', '^', '&', '*', '(', ')',  13,  27, 127,'\t', ' ', '_', '+', '{',
    '}', '|',   0, ':', '"', '~', '<', '>', '?', '|',   0,   0,   0,   0,   0,   0,
    // alt
      0,   0,   0,   0, 225,   0, 169,   0, 233,   0,   0,   0, 237,   0,   0,   0,
    181,   0, 243, 246, 228,   0, 223,   0, 250,   0, 229,   0, 252,   0, 161, 178,
    179, 164, 128, 188, 189, 190,   0,   0,   0,   0,   0,   0,   0, 165, 215, 147,
    148, 172,   0, 182, 180,   0,   0,   0, 191,   0,   0,   0,   0,   0,   0,   0,
    // alt - shift
      0,   0,   0,   0, 193,   0, 231,   0, 201,   0,   0,   0, 205,   0,   0,   0,
      0, 209, 211, 212, 196,   0, 167, 208, 218,   0, 197,   0, 220, 198, 185,   0,
      0, 163,   0, 176,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 247,   0,
      0, 166,   0,   0, 168,   0, 199,   0,   0,   0,   0,   0,   0,   0,   0,   0
};

const uint8_t Keyboard_BE[] = {
    // no shift
      0,   0,   0,   0, 'q', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', //  0 - 15
    ',', 'n', 'o', 'p', 'a', 'r', 's', 't', 'u', 'v', 'z', 'x', 'y', 'w', '&', 233, // 16 - 31
    '"',  39, '(', 167, 232, '!', 231, 224,  13,   0, 127,   9, ' ', ')', '-', '^', // 32 - 47
    '$', 181,   0, 'm', 249, 178, ';', ':', '=', '<',   0,   0,   0,   0,   0,   0, // 48 - 63
    // shift
      0,   0,   0,   0, 'Q', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
    '?', 'N', 'O', 'P', 'A', 'R', 'S', 'T', 'U', 'V', 'Z', 'X', 'Y', 'W', '1', '2',
    '3', '4', '5', '6', '7', '8', '9', '0',  13,   0, 127,   9, ' ', 176, '_', 168,
    '*', 163,   0, 'M', '%', 179, '.', '/', '+', '>',   0,   0,   0,   0,   0,   0,
    // alt
      0,   0,   0,   0,   0,   0,   0,   0, 128,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, '|',  '@',
    '#',   0,   0, '^',   0,   0, '{', '}',   0,   0,   0,   0,   0,   0,   0,  '[',
    ']', '`',   0,   0,   0,   0,   0,   0, '~',  92,   0,   0,   0,   0,   0,   0,
    // alt - shift
      0,   0,   0,   0,   0,   0,   0,   0, 128,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, '|',  '@',
    '#',   0,   0, '^',   0,   0, '{', '}',   0,   0,   0,   0,   0,   0,   0,  '[',
    ']', '`',   0,   0,   0,   0,   0,   0, '~',  92,   0,   0,   0,   0,   0,   0
};

const uint8_t Keyboard_UK[] = {  // to be checked
    // no shift
      0,   0,   0,   0, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', //  0 - 15
    'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2',
    '3', '4', '5', '6', '7', '8', '9', '0',  13,  27, 127,   9, ' ', '-', '=', '[',
    ']', '#',   0, ';',  39,  96, ',', '.', '/',  92,   0,   0,   0,   0,   0,   0, // 48 - 63
    // shift
      0,   0,   0,   0, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', // 64 - 79
    'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '!', '"', // 80 - 95
    163, '$', '%', '^', '&', '*', '(', ')',  13,  27, 127,   9, ' ', '_', '+', '{',
    '}', '~',   0, ':', '@', 171, '<', '>', '?', '|',   0,   0,   0,   0,   0,   0,
    // alt
      0,   0,   0,   0, 225,   0, 169,   0, 233,   0,   0,   0, 237,   0,   0,   0,
    181,   0, 243, 246, 228,   0, 223,   0, 250,   0, 229,   0, 252,   0, 161, 178,
    179, 128,   0, '^', 189, 190,   0,   0,   0,   0,   0,   0,   0, 165, 215, 147,
    148, '~',   0, 182, 180, 166,   0,   0, 191,   0,   0,   0,   0,   0,   0,   0,
    // alt - shift
      0,   0,   0,   0, 193,   0, 231,   0, 201,   0,   0,   0, 205,   0,   0,   0,
      0, 209, 211, 212, 196,   0, 167, 208, 218,   0, 197,   0, 220, 198, 185,   0,
      0,   0,   0, 176,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 247,   0,
    '|',  92,   0,   0,  92,   0, 199,   0,   0,   0,   0,   0,   0,   0,   0,   0
};

const uint8_t Keyboard_DE[] = { // German T1 keyboard layout
    // no shift
      0,   0,   0,   0, 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', //  0 - 15
    'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'z', 'y', '1', '2', // 16 - 31
    '3', '4', '5', '6', '7', '8', '9', '0',  13,  27, 127,'\t', ' ', 223, 180, 252, // 32 - 47
    '+', '#',   0, 246, 228, '^', ',', '.', '-', '<',   0,   0,   0,   0,   0,   0, // 48 - 63
    // shift
      0,   0,   0,   0, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
    'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Z', 'Y', '!', '"',
    167, '$', '%', '&', '/', '(', ')', '=',  13,  27, 127,'\t', ' ', '?', '`', 220,
    '*','\'',   0, 214, 196, 176, ';', ':', '_', '>',   0,   0,   0,   0,   0,   0,
    // alt
      0,   0,   0,   0,   0,   0,   0,   0, 128,   0,   0,   0,   0,   0,   0,   0,
    181,   0,   0,   0, '@',   0,   0,   0,   0,   0,   0,   0,   0,   0,   0, 178,
    179,   0, 128,   0, '{', '[', ']', '}',   0,   0,   0,   0,   0,'\\',   0, 147,
    '~',   0,   0,   0,   0,   0,   0,   0,   0, '|',   0,   0,   0,   0,   0,   0,
    // alt - shift
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,
      0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0,   0
 };

const uint8_t *KeyboardTable[] = { Keyboard_US, Keyboard_US_INTL, Keyboard_BE, Keyboard_UK, Keyboard_DE };

    
const uint8_t vowels[] = "aeiouAEIOU";
const uint8_t vw_tilde[] = "aonAON";

// Below lists may differ according to the keyboard selected
const uint8_t v_grave[] = { 224, 232, 236, 242, 249, 192, 200, 204, 210, 217 };
const uint8_t v_acute[] = { 225, 233, 237, 243, 250, 193, 201, 205, 211, 218 };
const uint8_t v_diaeresis[] = { 228, 235, 239, 246, 252, 196, 203, 207, 214, 220 };
const uint8_t v_tilde[] = { 227, 245, 241, 195, 213, 209 };
const uint8_t v_circum[] = { 226, 234, 238, 244, 251, 194, 202, 206, 212, 219 };

const sDeadKeyXlate dk_acute     = { vowels, v_acute };
const sDeadKeyXlate dk_diaeresis = { vowels, v_diaeresis };
const sDeadKeyXlate dk_grave     = { vowels, v_grave };
const sDeadKeyXlate dk_tilde     = { vw_tilde, v_tilde };
const sDeadKeyXlate dk_circum    = { vowels, v_circum };
const sDeadKeyXlate dk_null      = { NULL, NULL };

const sDictDkey dk_list_us_intl[] = { 
    {  52, &dk_acute },
    { 116, &dk_diaeresis},
    {  53, &dk_grave },
    { 117, &dk_tilde},
    {  99, &dk_circum},
    {   0, &dk_null }
 };

const sDictDkey dk_list_be[] = { 
    { 180, &dk_acute },
    { 111, &dk_diaeresis},
    { 177, &dk_grave },
    { 184, &dk_tilde},
    {  47, &dk_circum},
    {   0, &dk_null }
};

const sDictDkey dk_list_uk[] = { 
    { 180, &dk_acute },
    { 159, &dk_diaeresis},
    {  53, &dk_grave },
    { 177, &dk_tilde},
    { 163, &dk_circum},
    {   0, &dk_null }
};

const sDictDkey dk_list_de[] = {
    {  46,     &dk_acute },
    {  46+64,  &dk_grave },
    {  53,     &dk_circum},
    {   0,     &dk_null }
 };

const sDictDkey *KeyboardDictkeyTable[] = { NULL, dk_list_us_intl, dk_list_be, dk_list_uk, dk_list_de };

uint8_t err[6];
uint8_t (* scan_table[])(Keyboard *kb, uint8_t) = { KeybScanset1, KeybScanset2, KeybScanset3 };

/*******************************************************************************
* Function Name: check_parity
********************************************************************************
    *
* Summary:
*  takes the byte and transforms it in a code to insert in the keyboard fifo
*
* Parameters:
*  val the word to test
*
* Return:
*  0 if even, 1 if odd
*
*******************************************************************************/
uint8_t check_parity(uint16_t val) {
    uint8_t par = 0;
    while (val > 0) {
        if (val & 1) par++;
        val >>= 1;
    }
    return (par & 1);
}

/*******************************************************************************
* Function Name: KeybSetScanset
********************************************************************************
*
* Summary:
*  requests the current scanset or sets a new scanset
*
* Parameters:
*  val: 0: request current scanset, 1-3 set scanset 1-3
*
* Return:
*  Error code: 0 if success
* 
*
*******************************************************************************/
uint8_t KeybSetScanset(Keyboard *kb, uint8_t *sc_val) {
    uint8_t val = *sc_val;
    uint8_t ans;
    uint8_t err = 0;
    
    if (val > 3) return 1;
    
    err |= KeybSend(kb, 0xf0);

    KeybReadCode(kb, &ans);
    if (ans != 0xfa) err|= 2;
    
    err |= KeybSend(kb, val);

    KeybReadCode(kb, &ans);
    if (ans != 0xfa) err|= 2;
    
    if (val == 0) {
        KeybReadCode(kb, &ans);
    }
    
    if (val > 0 && val <=3 && (err == 0)) {
        kb->scanset = val;   // Set reported by keyboard
        kb->fp_scan = scan_table[val-1];
        kb->keyb_modifiers = 0;
        kb->keyb_lock_status = 0;
        kb->keyb_status = 0;
        KeybUpdateLeds(kb);
    }
    
    return ans;
}

/*******************************************************************************
* Function Name: KeybSetLayout
********************************************************************************
*
* Summary:
*  Changes the layout of the keyboard
*
* Parameters:
*  Pointer to the Keyboard structure
*  index to the keyboard to set
*
* Return:
*  none
*
*******************************************************************************/
void KeybSetLayout(Keyboard *kb, uint8_t layout) {
    if (layout >= sizeof(KeyboardTable) ) return;
    kb->kb_layout = (uint8_t *)   KeyboardTable[layout];
    kb->dk_xlate  = (sDictDkey *) KeyboardDictkeyTable[layout];
}

/*******************************************************************************
* Function Name: KeybInit
********************************************************************************
*
* Summary:
*  Sets up the low level keyboard functions
*  Sets initial values
*
* Parameters:
*  Pointer to the Keyboard structure
*
* Return:
*  none
*
*******************************************************************************/
void KeybInit(Keyboard *kb) {
    PS2kb_Init(kb);
    kb->dead_key    = 0;
    kb->prev_code   = 0;
    kb->keyb_status = 0;
    kb->keyb_modifiers = 0;
    kb->keyb_lock_status = 0;
    kb->newline = 0;
}

/*******************************************************************************
* Function Name: KeybReset
********************************************************************************
*
* Summary:
*  sends the reset code to the keyboard
*
* Parameters:
*  Pointer to the Keyboard structure
*
* Return:
*  none
*
*******************************************************************************/
void KeybReset(Keyboard *kb) {
    uint8_t scset = 0;
    KeybSend(kb, 0xff);
    CyDelay(200);
    KeybSetScanset(kb, &scset); // Request current scanset
}

/*******************************************************************************
* Function Name: KeybSend
********************************************************************************
*
* Summary:
*   Wrapper around low-level function, change name of function in single location
*   Also saves last byte sent. See low level function for detailed description
*
* Parameters:
*  pointer to Keyboard structure
*  value to send to keyboard
*
********************************************************************************/
uint8_t KeybSend(Keyboard *kb, uint8_t val) {
    kb->last_sent = val; // In case keyboard ask us to re-send the data
    return kb->write(val);
}

/*******************************************************************************
* Function Name: KeybResend
********************************************************************************
*
* Summary:
*   Wrapper around low-level function, change name of function in single location
*   Also saves last byte sent. See low level function for detailed description
*
* Parameters:
*  pointer to Keyboard structure
*
********************************************************************************/
uint8_t KeybResend(Keyboard *kb) {
    return kb->write(kb->last_sent);
}


/*******************************************************************************
* Function Name: KeybReadImm
********************************************************************************
*
* Summary:
*  Non blocking read. May give erroneous result if no data is available
*
* Parameters:
*  pointer to Keyboard structure
*  pointer to a variable where the character received can be stored
*
* Return:
*  Bit mask giving error code
*  0: no error
*  bit 1: wrong parity
*  bit 2: missing start bit
*  bit 3: missing stop bit
*
*******************************************************************************/
uint8_t KeybReadImm(Keyboard *kb, uint8_t *ch) {
    
    uint16_t scancode = kb->read();
    uint8_t  rval = 0;
    
    if ( (scancode & 0x0400) == 0) {
        // Must have 1 stop bit
        rval |= 4;
    }
    if ( (scancode & 1) != 0) {
        // Must have 0 start bit
        rval |= 2;
    }
    if (! check_parity(scancode & 0x3ff)) { 
        // Must have odd parity
        rval |= 1;
    }

    *ch = (scancode >> 1) & 0xff; // Remove parity, start and stop bits
    
    return rval;
}

/*******************************************************************************
* Function Name: KeybReadCode
********************************************************************************
*
* Summary:
*  Blocking read. Waits until a code becomes available, then calls keyb_read_imm
*
* Parameters:
*  pointer to Keyboard structure
*  pointer to a variable where the character received can be stored
*
* Return: see KeybReadImm
*
*******************************************************************************/
uint8_t KeybReadCode(Keyboard *kb, uint8_t *ch_ptr) {
    
    while ( ( kb->status() & 0x01u ) == 0) {}
    
    return KeybReadImm(kb, ch_ptr);
    
}

/*******************************************************************************
* Function Name: KeybReadUsb
********************************************************************************
*
* Summary:
*  Non-Blocking read. Gets a scancode and converts it into an USB code
*
* Parameters:
*  pointer to Keyboard structure
*  pointer to a variable where the character received can be stored
*
* Return:  0 if nothing received
*          code representing USB keycode
*
*******************************************************************************/
uint8_t KeybReadUsb(Keyboard *kb) {
    uint8_t  keycode, usb_code = 0;
    
    if (KeybReadImm(kb, &keycode) == 0) {
        usb_code = kb->fp_scan(kb, keycode);
    }

    return usb_code;
    
}

/*******************************************************************************
* Function Name: KeybUpdateLeds
********************************************************************************
*
* Summary: Updates the keyboard LEDS with the current lock status
*
* Parameters: 
*  pointer to Keyboard structure
*  lock_sts is the bit mask of the leds to set or clear
*
* Return:
*  0 if successful
*  bit 1 set: transmission failed, maybe no keyboard attached?
*  bit 2 set: no confirmation was received on command byte
*  bit 3 set: no confirmation was received on status byte
*
*******************************************************************************/
uint8_t KeybUpdateLeds(Keyboard *kb) {
    uint8_t ans, err;

    err = KeybSend(kb, 0xed);
    
    KeybReadCode(kb, &ans);
    
    if (ans != 0xfa) err |= 2;
    
    err |= KeybSend(kb, kb->keyb_lock_status);
    
    KeybReadCode(kb, &ans);
    
    if (ans != 0xfa) err |= 4;
       
    return err;

}

/*******************************************************************************
* Function Name: KeybLock
********************************************************************************
*
* Summary:
*  Handles CAPS-, NUM-, and SCROLL-lock
*  Changes the lock status and turns lock status led light on/off
*  Ignores key repeats when key is held.
*
* Parameters:
*  pointer to Keyboard structure
*  lock: bit to change (see KEYB_xxx_LOCK defines)
*  pressed: 1 if key is pressed, 0 if key is released
*
* Return:
*  0 if successful
*  bit 1 set: transmission failed, maybe no keyboard attached?
*  bit 2 set: no confirmation was received on command byte
*  bit 3 set: no confirmation was received on status byte
*******************************************************************************/
/* Lock status */
    static uint8_t keyb_state_change = 0;
uint8_t KeybLock(Keyboard *kb, uint8_t lock, uint8_t pressed) {
    
    if (!pressed) { // key is released
        keyb_state_change &= ~lock; // clear active status
        return 0;
    } else {
        if (pressed == 1) {
            if (keyb_state_change & lock) return 0; // already active change
            keyb_state_change |= lock;
        }
        if (kb->keyb_lock_status & lock) {
            // bit is set
            kb->keyb_lock_status &= ~lock;
        } else {
            // bit is not set
            kb->keyb_lock_status |= lock;
        }
    }
    
    err[0] = KeybUpdateLeds(kb);
    return err[0];
}

/*******************************************************************************
* Function Name: KeybSetModifiers
********************************************************************************
*
* Summary: Handles the modifiers, these are the shift-, alt-, ctrl keys and the
*          scroll-, num- and shift-lock keys
*
* Parameters:
*  pointer to Keyboard structure
*  code: scancode as read from keyboard
*  make: 1 on a make request, 0 on a break
*
* Return: none
          
*******************************************************************************/
void KeybSetModifiers(Keyboard *kb, uint8_t code, uint8_t make) {
    
    switch (code) {
            case 57:  KeybLock(kb, KEYB_CAPS_LOCK, make); break;
            case 71:  KeybLock(kb, KEYB_SCROLL_LOCK, make); break;
            case 83:  KeybLock(kb, KEYB_NUM_LOCK, make); break;
    }
    if (code < 224) return;
    
    if (make) {
        switch (code) {
            case 224: kb->keyb_modifiers |= KEY_LEFT_CTRL; break;
            case 225: kb->keyb_modifiers |= KEY_LEFT_SHIFT; break;
            case 226: kb->keyb_modifiers |= KEY_LEFT_ALT; break;
            case 227: kb->keyb_modifiers |= KEY_LEFT_WIN; break;
            case 228: kb->keyb_modifiers |= KEY_RIGHT_CTRL; break;
            case 229: kb->keyb_modifiers |= KEY_RIGHT_SHIFT; break;
            case 230: kb->keyb_modifiers |= KEY_RIGHT_ALT; break;
            case 231: kb->keyb_modifiers |= KEY_RIGHT_WIN; break;
        }
    } else { // Release key
        switch (code) {
            case 224: kb->keyb_modifiers &= ~KEY_LEFT_CTRL; break;
            case 225: kb->keyb_modifiers &= ~KEY_LEFT_SHIFT; break;
            case 226: kb->keyb_modifiers &= ~KEY_LEFT_ALT; break;
            case 227: kb->keyb_modifiers &= ~KEY_LEFT_WIN; break;
            case 228: kb->keyb_modifiers &= ~KEY_RIGHT_CTRL; break;
            case 229: kb->keyb_modifiers &= ~KEY_RIGHT_SHIFT; break;
            case 230: kb->keyb_modifiers &= ~KEY_RIGHT_ALT; break;
            case 231: kb->keyb_modifiers &= ~KEY_RIGHT_WIN; break;
        }
    }
}

/*******************************************************************************
* Function Name: KeybGetModifiers
********************************************************************************
*
* Summary:
*  Returns the currently active modifier keys
*  
* Parameters:
*  pointer to Keyboard structure
*
* Return: The currently active modifier keys
*
*******************************************************************************/
uint8_t KeybGetModifiers(Keyboard *kb) {
    return kb->keyb_modifiers;
}

/*******************************************************************************
* Function Name: KeybScanset1
********************************************************************************
*
* Summary:
*  Transforms a scanset 1 code in a usb code.
*  Also updates the modifier keys
*
* Parameters:
*  pointer to Keyboard structure
*  code: scancode as read from keyboard
*
* Return: 0 if nothing needs to be done. USB code when not zero.
*         Released keys also return 0.
*******************************************************************************/
uint8_t KeybScanset1(Keyboard *kb, uint8_t code) {
    uint8_t rval = 0;
    uint8_t make = (code & 0x80) ? 0 : 1;

    switch (code) {
        case 0xe0: kb->keyb_status |= KEYB_EXTENDED; return 0;
        case 0xfa: return 0; // Acknowledge
        case 0xfe: KeybResend(kb); return 0; // resend
    }
    
    code &= 0x7f;

    // Handle extended characters first
    if (kb->keyb_status & KEYB_EXTENDED) {
        kb->keyb_status &= ~KEYB_EXTENDED;
        switch (code) { // To be executed on release as well
                case 0x5b: KeybSetModifiers(kb, 227, make); break; // LGUI
                case 0x1d: KeybSetModifiers(kb, 228, make); break; // Right CTRL
                case 0x38: KeybSetModifiers(kb, 230, make); break; // Right ALT
                case 0x5c: KeybSetModifiers(kb, 231, make); break; // RGUI
        }
        if (make) { // Only on make
            switch (code) {
                case 0x1c: rval = 88; break;
                case 0x35: rval = 84; break;
                case 0x37: rval = 70; break;
                case 0x47: rval = 74; break;
                case 0x48: rval = 82; break;
                case 0x49: rval = 75; break;
                case 0x4b: rval = 80; break;
                case 0x4d: rval = 79; break;
                case 0x4f: rval = 77; break;
                case 0x50: rval = 81; break;
                case 0x51: rval = 78; break;
                case 0x52: rval = 73; break;
                case 0x53: rval = 76; break;
            }
        }
        return rval;
    }
    

    if (code < sizeof(scanset1_to_usb)) {
        rval = scanset1_to_usb[code];
        KeybSetModifiers(kb, rval, make);
    }
    
    if (make) {
        return rval;
    } else
        return 0;
}

/*******************************************************************************
* Function Name: KeybScanset2
********************************************************************************
*
* Summary:
*  Transforms a scanset 2 code in a usb code.
*  Also updates the modifier keys
*
* Parameters:
*  pointer to Keyboard structure
*  code: scancode as read from keyboard
*
* Return: 0 if nothing needs to be done. USB code when not zero.
*         Released keys also return 0.
*******************************************************************************/
uint8_t KeybScanset2(Keyboard *kb, uint8_t code) {
    uint8_t rval = 0;
    uint8_t make;
    
    if (kb->keyb_status & KEYB_EXTENDED) {
        if (code == 0xF0) { // do not clear extended status yet
            kb->keyb_status |= KEYB_RELEASE;
            return rval;
        }
        kb->keyb_status &= ~KEYB_EXTENDED;
        if (kb->keyb_status & KEYB_RELEASE) {
            kb->keyb_status &= ~KEYB_RELEASE;
            switch (code) {
                case 0x1f: KeybSetModifiers(kb, 227,0); break;
                case 0x14: KeybSetModifiers(kb, 228,0); break;
                case 0x11: KeybSetModifiers(kb, 230,0); break;
                case 0x27: KeybSetModifiers(kb, 231,0); break;
            }
        } else {
            // Handle extended keys first time
            switch (code) { // Mostly middle keypad
                case 0x1f: KeybSetModifiers(kb, 227,1); break;
                case 0x14: KeybSetModifiers(kb, 228,1); break;
                case 0x11: KeybSetModifiers(kb, 230,1); break;
                case 0x27: KeybSetModifiers(kb, 231,1); break;
                case 0x69: rval =  77; break; // End
                case 0x6b: rval =  80; break; // Left
                case 0x6c: rval =  74; break; // Home
                case 0x70: rval =  73; break;
                case 0x71: rval =  73; break;
                case 0x72: rval =  81; break; // Down
                case 0x74: rval =  79; break; // Right
                case 0x75: rval =  82; break; // Up
                case 0x7a: rval =  78; break;
                case 0x7c: rval =  70; break;
                case 0x7d: rval =  75; break;
                case 0x4a: rval =  84; break;
                case 0x5a: rval =  88; break;   
            }
        }
        return rval;
    }
    
    make = !(kb->keyb_status & KEYB_RELEASE);
    
    if (code < sizeof(scanset2_to_usb)) {
        rval = scanset2_to_usb[code];
        KeybSetModifiers(kb, rval, make);
    }
    
    if (kb->keyb_status & KEYB_RELEASE) {
        kb->keyb_status &= ~KEYB_RELEASE;
        return 0;
    }
    
    switch (code) {
        case 0xF0: kb->keyb_status |= KEYB_RELEASE; break;
        case 0xE0: kb->keyb_status |= KEYB_EXTENDED; break;
        case 0xfa: break; // Acknowledge
        case 0xfe: KeybResend(kb); break; // resend
    }
    
    return rval;
}

/*******************************************************************************
* Function Name: KeybScanset3
********************************************************************************
*
* Summary:
*  Transforms a scanset 3 code in a usb code.
*  Also updates the modifier keys
*  
*
* Parameters:
*  kb:   pointer to Keyboard structure
*  code: scancode as read from keyboard
*
* Return: 0 if nothing needs to be done. USB code when not zero.
*         Released keys also return 0.
*******************************************************************************/
uint8_t KeybScanset3(Keyboard *kb, uint8_t code) {
    uint8_t rval = 0;
    uint8_t make = (kb->keyb_status & KEYB_RELEASE) ? 0 : 1;

    if (code < sizeof(scanset3_to_usb)) rval = scanset3_to_usb[code];

    if (rval > 223) { // Handle modifier keys
        if (!make) { // Only for keys that have release code
            switch (rval) {
                case 224: // L-CTRL
                case 225: // L-SHIFT
                case 226: // L-ALT
                case 229: // R-SHIFT
                   KeybSetModifiers(kb, rval, 0);
            }
        }
        else {
            KeybSetModifiers(kb, rval, 1);
            kb->keyb_status |= KEYB_MODIF;
        }
    } 
    else
    if (rval > 0) {
        if (kb->keyb_status & KEYB_MODIF) {
            kb->keyb_status |= KEYB_MODIF_USED;
            kb->keyb_status &= ~KEYB_MODIF;
        } else
        if (kb->keyb_status & KEYB_MODIF_USED) {
            kb->keyb_modifiers &= 0x27; // Clear all pending modifiers except some left keys or right shift
            kb->keyb_status &= ~KEYB_MODIF_USED;
        }
    }

    switch (rval) {
            case 57:  KeybLock(kb, KEYB_CAPS_LOCK, make); break;
            case 71:  KeybLock(kb, KEYB_SCROLL_LOCK, 1); keyb_state_change &= ~KEYB_SCROLL_LOCK; break;
            case 83:  KeybLock(kb, KEYB_NUM_LOCK, 1); keyb_state_change &= ~KEYB_NUM_LOCK; break;
    }

    kb->keyb_status &= ~KEYB_RELEASE; // Clear any pending release
    
    // Some special codes
    switch (code) {
            case 0xF0: kb->keyb_status |= KEYB_RELEASE; break;
            case 0xfa: break; // Acknowledge
            case 0xfe: KeybResend(kb); break; // resend
    }
    
    return make ? rval : 0;

}

/*******************************************************************************
* Function Name: KeybCsi
********************************************************************************
*
* Summary:
*  Fill the buffer with the Control Sequense Indicator and add the given string.
*
* Parameters:
*  In:
*    str   String to add after <ESC> [
*
*  Out:
*    buf   output pointer to a character buffer to hold the generated sequence
*
*  Return: Number of characters in character buffer.
*
*******************************************************************************/
static uint8_t KeybCsi(char *buf, const char* str) {
    buf[0] = 0x1b;
    buf[1] = '[';
    strcpy(&buf[2], str);
    
    return strlen(str) + 2;
}
   
/*******************************************************************************
* Function Name: KeybDeadKey
********************************************************************************
*
* Summary:
*  Check if key entered is a dead key, depending on current keyboard layout.
*  If previous key was a dead key, then generate the character representing
*  the dead key followed by the current key and return it in the buffer.
*  If the character is the same dead key, it will appear twice, eg: ""
*  If a dead key is followed by a space, only the dead character is returned.
*
* Parameters:
*  In
*     kb:         Pointer to Keyboard structure
*     ch_index:   Index into the character lookup table
*
*  Out:
*     buf         Pointer to a character buffer to hold the generated sequence
*
*  Return: Number of characters in character buffer.
*
*******************************************************************************/
static uint8_t KeybDeadKey(Keyboard *kb, char *buf, uint16_t ch_index) {
    sDictDkey     *dkey_list = kb->dk_xlate;
    uint16_t dkey = kb->dead_key;
    uint8_t  ch = kb->kb_layout[ch_index];
    uint8_t  rval = 0;
    
    if (NULL == dkey_list && ch > 0) { // No dead keys defined
        buf[0] = ch;
        return 1;
    }
    
    if (dkey > 0) { // Active dead key
        if (ch == ' ') { // When space, return dead key
            buf[0] = kb->kb_layout[dkey];
            rval = 1;
        } else
        if (ch_index != dkey) { // translate eg: a->á
            uint8_t i = 0;
            uint8_t mch;
            do { // Match current character
                mch = kb->xlate_info->key_orig[i];
                if (ch == mch) {
                    buf[0] = kb->xlate_info->key_accent[i];
                    rval = 1;
                    break;
                }
                i++;
            } while (mch > 0);
                    
            if (rval == 0) { // We did not find a match, output dead key and character
                buf[0] = kb->kb_layout[dkey];
                buf[1] = ch;
                rval = 2;
            }
        } else { // twice same dead key
            buf[1] = buf[0] = ch;
            rval = 2;
        }
        kb->dead_key = 0; // Deactivate dead key
    }
    else { // No active dead key
        uint8_t dk_idx = 0;
        uint16_t dk_value;
        do {
            dk_value = dkey_list[dk_idx].dk_index;
            if (dk_value == ch_index) {
                // We found a match
                kb->dead_key = ch_index; // Keep dead key.
                kb->xlate_info = (sDeadKeyXlate *)dkey_list[dk_idx].dk_xlate; // Keep translation table
                break;
            }
            dk_idx++;
        } while (dk_value > 0);
        
        if (dk_value == 0) { // no matching key, output character
            if (ch > 0) {
                buf[0] = ch;
                rval = 1;
            }
        }

    }
    
    return rval;
}

/*******************************************************************************
* Function Name: KeybUsb2Ansi
********************************************************************************
*
* Summary:
*  Transforms a usb code in an ascii value or ansi escape sequence.
*
* Parameters:
*  In:
*    kb   pointer to Keyboard structure
*    code usb code received from keyboard
*
*  Out:
*    buf  output pointer to a character buffer, it may be filled with multiple characters
*
*  Return: Number of characters in character buffer.
*
*******************************************************************************/
uint8_t KeybUsb2Ansi(Keyboard *kb, char *buf, uint8_t code) {
    buf[1] = buf[0] = 0;
    if (code == 0) return 0;
    uint8_t keyb_shifted = (kb->keyb_modifiers & (KEY_LEFT_SHIFT | KEY_RIGHT_SHIFT)) ? 1 : 0;
    uint8_t keyb_ctrl = (kb->keyb_modifiers & (KEY_LEFT_CTRL | KEY_RIGHT_CTRL)) ? 1 : 0;
    uint8_t keyb_alt = kb->keyb_modifiers & KEY_RIGHT_ALT;
    uint8_t rval = 0;
    uint8_t ch = 0;
    
    // Handle numeric keypad when numlock is set
    if (code >= 84 && code < 89) {ch = NUM_pad[code - 84]; rval = 1;}
    if (code >= 89 && code < 100 && (kb->keyb_lock_status & KEYB_NUM_LOCK)) {ch=NUM_pad[code - 84];rval=1;}
    if (rval > 0) { buf[0] = ch; }
    // End numeric keypad
    
    keyb_shifted ^= (kb->keyb_lock_status & KEYB_CAPS_LOCK) ? 1 : 0;
    
    // Printable characters
    if (code <= 56 ) {
        // Should handle ctrl characters first
        if (keyb_ctrl) { // When ctrl is pressed CTRL-A to CTRL-Z are mapped to ascii 1 till 26.
            // Need first to translate the USB code to a character, because of the different keyboard layouts.
            ch = kb->kb_layout[code];
            if (ch >= 'a' && ch <= 'z') {
                ch = ch - 'a' + 1;
            }
            // Store character in the buffer
            if (ch > 0) {
                rval = 1;
                buf[0] = ch;
            }
        }
        else {
            uint16_t ch_index = code + (keyb_shifted ? 64 : 0) + (keyb_alt ? 128 : 0);
            // Check for dead keys...
            rval = KeybDeadKey(kb, buf, ch_index);
        }
        
        // Handle automatic linefeed
        if (buf[0] == '\r'&& kb->newline) {
            buf[1] = '\n';
            buf[2] = 0;
            rval = 2;
        }
        
    } else { // code > 56
        
        switch (code) {
            case 58: rval = keyb_shifted ? KeybCsi(buf, "23~") : KeybCsi(buf, "11~"); break; // F1
            case 59: rval = keyb_shifted ? KeybCsi(buf, "24~") : KeybCsi(buf, "12~"); break; // F2
            case 60: rval = keyb_shifted ? KeybCsi(buf, "25~") : KeybCsi(buf, "13~"); break; // F3
            case 61: rval = keyb_shifted ? KeybCsi(buf, "26~") : KeybCsi(buf, "14~"); break; // F4
            case 62: rval = keyb_shifted ? KeybCsi(buf, "28~") : KeybCsi(buf, "15~"); break; // F5
            case 63: rval = keyb_shifted ? KeybCsi(buf, "29~") : KeybCsi(buf, "17~"); break; // F6
            case 64: rval = keyb_shifted ? KeybCsi(buf, "31~") : KeybCsi(buf, "18~"); break; // F7
            case 65: rval = keyb_shifted ? KeybCsi(buf, "32~") : KeybCsi(buf, "19~"); break; // F8
            case 66: rval = keyb_shifted ? KeybCsi(buf, "33~") : KeybCsi(buf, "20~"); break; // F9
            case 67: rval = keyb_shifted ? KeybCsi(buf, "34~") : KeybCsi(buf, "21~"); break; // F10
            case 68: rval = KeybCsi(buf, "23~"); break; // F11
            case 69: rval = KeybCsi(buf, "24~"); break; // F12
            case 73: rval = KeybCsi(buf, "2~"); break;  // Insert
            case 74: rval = KeybCsi(buf, "1~"); break;  // Home
            case 75: rval = KeybCsi(buf, "5~"); break;  // Page Up
            case 76: rval = KeybCsi(buf, "3~"); break;  // Delete
            case 77: rval = KeybCsi(buf, "4~"); break;  // End
            case 78: rval = KeybCsi(buf, "6~"); break;  // Page Down
            case 79: rval = KeybCsi(buf, "C"); break;   // Right
            case 80: rval = KeybCsi(buf, "D"); break;   // Left
            case 81: rval = KeybCsi(buf, "B"); break;   // Down
            case 82: rval = KeybCsi(buf, "A"); break;   // Up
            case 100: // INT 1 key on some keyboards, map it to 57 for translation
                buf[0] = kb->kb_layout[57 + (keyb_shifted ? 64 : 0) + (keyb_alt ? 128 : 0)];
                rval = 1;
                break;
        }
        if ((kb->keyb_lock_status & KEYB_NUM_LOCK) == 0) {
            switch (code) {
                case 89: rval = KeybCsi(buf, "3~"); break;  // KP Delete
                case 90: rval = KeybCsi(buf, "B"); break;   // KP Down
                case 91: rval = KeybCsi(buf, "6~"); break;  // KP Page Down
                case 92: rval = KeybCsi(buf, "D"); break;   // KP Left
                case 94: rval = KeybCsi(buf, "C"); break;   // KP Right
                case 95: rval = KeybCsi(buf, "H"); break;   // KP Home
                case 96: rval = KeybCsi(buf, "A"); break;   // KP Up
                case 97: rval = KeybCsi(buf, "5~"); break;  // KP Page Up
                case 98: rval = KeybCsi(buf, "2~"); break;  // KP Insert
                case 99: rval = KeybCsi(buf, "4~"); break;  // KP End
            }
        }
        
    }
    
    return rval;
}


/* [] END OF FILE */
