/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#if !defined(PV_PS2_PS2kb_H)
#define PV_PS2_PS2kb_H

#include "cyfitter.h"
#include "cytypes.h"
#include "keyboard.h"
//#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

/***************************************
*        Function Prototypes
***************************************/

uint16_t PS2kb_GetScancode(void) ;
void     PS2kb_Init(Keyboard *);
uint8_t  PS2kb_GetStatus(void);
uint8_t  PS2kb_Send(uint8_t val) ;

/***************************************
*        Registers Constants
***************************************/
/* B_PS2kb Status Register */
    #define PS2kb_KB_CODE_AVAILABLE    (0x01u) /* F1 fifo not empty */
    #define PS2kb_KB_RX_FIFO_FULL      (0x02u) /* F1 fifo full */
    #define PS2kb_KB_TX_FIFO_EMPTY     (0x04u) /* F0 fifo empty */
    #define PS2kb_KB_TX_FIFO_NOT_FULL  (0x08u) /* F0 fifo not full */
    #define PS2kb_KB_ACK               (0x10u) /* Host to Keyboard command acknowledge */
    #define PS2kb_KB_TX_END            (0x20u) /* Host to Keyboard transmission finished */
    #define PS2kb_KB_RX_DATA_END       (0x40u) /* Keyboard to host transmission finished */

#endif /* (PV_SP2_PS2kb_H) */
/* [] END OF FILE */
