/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#if !defined(PV_PS2_`$INSTANCE_NAME`_H)
#define PV_PS2_`$INSTANCE_NAME`_H

#include "cyfitter.h"
#include "cytypes.h"
#include "keyboard.h"
//#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

/***************************************
*        Function Prototypes
***************************************/

uint16_t `$INSTANCE_NAME`_GetScancode(void) `=ReentrantKeil($INSTANCE_NAME . "_GetScancode")`;
void     `$INSTANCE_NAME`_Init(Keyboard *)`=ReentrantKeil($INSTANCE_NAME . "_Init")`;
uint8_t  `$INSTANCE_NAME`_GetStatus(void)`=ReentrantKeil($INSTANCE_NAME . "_GetStatus")`;
uint8_t  `$INSTANCE_NAME`_Send(uint8_t val) `=ReentrantKeil($INSTANCE_NAME . "_Send")`;

/***************************************
*        Registers Constants
***************************************/
/* B_PS2kb Status Register */
    #define `$INSTANCE_NAME`_KB_CODE_AVAILABLE    (0x01u) /* F1 fifo not empty */
    #define `$INSTANCE_NAME`_KB_RX_FIFO_FULL      (0x02u) /* F1 fifo full */
    #define `$INSTANCE_NAME`_KB_TX_FIFO_EMPTY     (0x04u) /* F0 fifo empty */
    #define `$INSTANCE_NAME`_KB_TX_FIFO_NOT_FULL  (0x08u) /* F0 fifo not full */
    #define `$INSTANCE_NAME`_KB_ACK               (0x10u) /* Host to Keyboard command acknowledge */
    #define `$INSTANCE_NAME`_KB_TX_END            (0x20u) /* Host to Keyboard transmission finished */
    #define `$INSTANCE_NAME`_KB_RX_DATA_END       (0x40u) /* Keyboard to host transmission finished */

#endif /* (PV_SP2_`$INSTANCE_NAME`_H) */
/* [] END OF FILE */
