/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "window.h"

#ifndef TERMINAL_H
#define TERMINAL_H

#define TERM_SETTINGS_NUM 14
#define MAX_COUNT 40
    
typedef enum { TERMINAL, SETUP_MAIN, SETUP_SUB } TerminalModus;
typedef enum { FT_NEWLINE, FT_TYPEMATIC, FT_KB_LAYOUT, FT_KB_SCANSET, FT_FG_COLOR, FT_BG_COLOR,
               FT_CURSOR_TYPE, FT_SIZE_X, FT_SIZE_Y, FT_WRAP, FT_LOCAL, FT_SERPORT, FT_BAUDRATE, FT_CHARSET } eTerminalFeature;
typedef enum { CS_UTF_8, CS_WIN1252, CS_ISO_8859_1 } eCharacterSet;
typedef enum { ESC_NONE, ESC_ESC, ESC_CSI, ESC_SS2, ESC_SS3, ESC_DCS, ESC_ST, ESC_OSC } escMode;


typedef struct _buffer {
    int count;
    int maxlen;
    uint8_t buff[MAX_COUNT];
} Buffer_t;

typedef struct Terminal {
    Window *win;
    Keyboard *kb;
    TerminalModus mode;
    escMode seqMode;
    uint8_t term_settings[TERM_SETTINGS_NUM];
    Buffer_t SerInBuf;
    Buffer_t SerOutBuf;
    Buffer_t EscapeBuf;
    char keyb_buf[20];
} Terminal;

void BufferInit(Buffer_t *cb);
int  BufferAdd(Buffer_t *cb, uint8_t ch);

void TermInit(Terminal *term, Window *win, Keyboard *kb);
void TermSetupModify(Terminal *tm, eTerminalFeature sel0, uint8_t sel1);
void TermDispatch(Terminal *term);
void TermDisplay(Terminal *term, uint8_t ch);
void TermTransmit(Terminal *term, uint8_t code);
void TermKeybRead(Terminal *term);
void TermReceive(Terminal *term);
void TermSetBaudrate(uint8_t sel);
escMode TermCS1(uint8_t ch);

extern uint32_t tm_mask;

#endif
/* [] END OF FILE */
