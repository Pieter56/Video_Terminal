/* ===================================================================== *
 *                                                                       *
 * Copyright (C) 2022 by Pieter Vandevoorde                              *
 *                                                                       *
 * This program is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation, either version 3 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 *                                                                       *
 * ===================================================================== *
*/
#include "project.h"
#include "terminal.h"
#include "window.h"
#include "menu.h"


Menu menu1 = { 2, 3, NULL, { "OFF", "ON" } };
Menu menu_textx = { 4, 2, NULL, { "1", "2", "3", "4" } };
Menu menu_texty = { 2, 2, NULL, { "1", "2" } };
Menu menu_scanset = { 4, 4, NULL, { "AUTO", "1", "2", "3" } };
Menu menu_cursor = { 3, 9, NULL, { "OFF", "UNDERLINE", "BLOCK" } };
Menu menu_color = { 8, 7, NULL, { "BLACK", "RED", "GREEN", "YELLOW ", "BLUE", "MAGENTA", "CYAN", "WHITE" } };
Menu menu_layout = { 5, 7, NULL, { "US", "US INTL", "Belgian", "UK INTL", "German"} };
Menu menu_serport = { 2, 15, NULL, { "Rx=12.2 Tx=12.3", "Rx=12.6 Tx=12.7" } };
Menu menu_baudrate = { 10, 6, NULL, { "115200", "57600", "38400", "28800", "19200", "14400", "9600", "7200", "4800", "3600" } };
Menu menu_charset = { 3, 12, NULL, { "UTF-8", "Win 1252", "ISO-8859-1" } };
Menu *menu_main_sub[] = { &menu1, &menu1, &menu_layout, &menu_scanset, &menu_color, &menu_color,
                          &menu_cursor, &menu_textx, &menu_texty, &menu1, &menu1, &menu_serport, &menu_baudrate, &menu_charset };
Menu menu_main = { 14, 16, &menu_main_sub, {
                        "Newline", "Auto Repeat", "Keyboard Layout", "Scanset",
                        "Foreground Color", "Background Color",
                        "Cursor", "Textsize X", "Textsize Y", "Wrap Around", 
                        "Line local", "Serial Port", "Baudrate", "Character Set"} };


/*******************************************************************************
* Function Name: MenuShowMain
********************************************************************************
*
* Summary:
*  Displays the main menu and the selected item.
*  
* Parameters:
*  tm:    pointer to Terminal structure
*  main:  pointer to main menu structure
*  sel:   selected item of main menu.
*  level: if > 0, show selection in submenu
*
* Return: number of items in submenu
*
*******************************************************************************/																				
uint8_t MenuShowMain(Terminal *tm, Menu *main, uint8_t sel, uint8_t level) {
    uint8_t val, menu_w, menu_h;
    Window *win = tm->win;
    char *menu_str, *val_str;
    Menu *sub_menu;
    
    menu_w = (main->item_len + 16) * win->bb_x;
    menu_h = win->bb_y * main->items;
    
    ScreenFillRect(win->orig_x + 10, win->orig_y + 20, menu_w + 10, menu_h + 10, 0);
    
    ScreenDrawRect(win->orig_x + 10, win->orig_y + 20, menu_w + 10, menu_h + 10, 1);
    
    ScreenDrawVertLine(win->orig_x + 18 + main->item_len * win->bb_x, win->orig_y + 23, menu_h + 4, 1);
    
    ScreenDrawRect(win->orig_x + 12, win->orig_y + 22, menu_w + 6, menu_h + 6, 1);

    for (uint8_t m = 0; m < main->items; m++) {
        menu_str = main->values[m];
        WindowSetCursor(win, 2 * win->bb_x, 25 + win->bb_y * m);
        WindowWriteString(win, menu_str, (m == sel) ? 1 : 0);
        
        WindowSetCursor(win, (3 + main->item_len) * win->bb_x, 25 + win->bb_y * m);
        val = tm->term_settings[m];
        sub_menu = (*main->submenu)[m];
        val_str = sub_menu->values[val];
        WindowWriteString(win, val_str, (level && (m == sel)) ? 1 : 0);
    }

    return main->items;
}

/*******************************************************************************
* Function Name: MenuShowSub
********************************************************************************
*
* Summary:
*  Displays the main menu and the selected item.
*  
* Parameters:
*  win:        pointer to Window structure
*  sub_menu:   pointer to main menu structure
*  sel1:       selected item of submenu
*  erase:      if > 0, erase submenu and leave
*  offset_x, offset_y:  where to draw submenu
*
* Return: number of items in submenu
*
*******************************************************************************/																				
void MenuShowSub(Window *win, Menu *sub_menu, uint8_t sel1, uint8_t erase, int16_t offset_x, int16_t offset_y) {
    uint8_t items = sub_menu->items;
    
    // Clear everything before drawing the menu
    ScreenFillRect(win->orig_x + 8 + offset_x, win->orig_y + 20 + offset_y,
         sub_menu->item_len * win->bb_x + 10, win->bb_y * items + 10, 0);

    if (erase) return;
    
    // Draw outer border
    ScreenDrawRect(win->orig_x + 8 + offset_x, win->orig_y + 20 + offset_y,
         sub_menu->item_len * win->bb_x + 10, win->bb_y * items + 10, 1);
    
    // Draw inner border
    ScreenDrawRect(win->orig_x + 10 + offset_x, win->orig_y + 22 + offset_y,
         sub_menu->item_len * win->bb_x + 6, win->bb_y * items + 6, 1);
        
    for (uint8_t m = 0; m < items; m++) {
        WindowSetCursor(win, 2 * win->bb_x + offset_x, 25 + win->bb_y * m + offset_y);
        WindowWriteString(win, sub_menu->values[m], (m == sel1) ? 1 : 0);
    }

}
/* [] END OF FILE */
