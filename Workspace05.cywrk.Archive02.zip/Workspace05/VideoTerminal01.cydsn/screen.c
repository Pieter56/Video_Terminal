/* ===================================================================== *
 *                                                                       *
 * Copyright (C) 2022 by Pieter Vandevoorde                              *
 *                                                                       *
 * This program is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation, either version 3 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 *                                                                       *
 * ===================================================================== *
*/
#include "project.h"
#include "stdlib.h"

#include "screen.h"
#include "window.h"

#ifndef _swap_int16_t
#define _swap_int16_t(a, b)                                                    \
  {                                                                            \
    int16_t t = a;                                                             \
    a = b;                                                                     \
    b = t;                                                                     \
  }
#endif


// Global variables used in this module
Screen scrn;

static uint16_t cur_line;     // current video line out of TOT_LINES (0-749), includes blanking area
static uint16_t disp_line;    // active video line out of ACT_LINES (0-719)
static uint16_t frame_count;  // currently used to blink the cursor, can be used as an accurate timer

uint8 DMA_VGA_Line_TD[1];

volatile uint32_t scn_mask; // Bitmask. All bits will be set by frame interrupt routine

#define BLINK_MASK    1
#define FRAME_MASK    2
#define CONWAY_MASK   4

/*******************************************************************************
* Function Name: VGA_InitDMA
********************************************************************************
*
* Summary:
*  Initialises the DMA that copies words of pixels from memory to the UDB
*  block that writes pixels to the screen.
*  The DMA copies one video line from memory to the screen,
*  after every 2 lines the starting address has to be adjusted to point to the
*  next video line. This is taken care of by an interrupt routine.
*
********************************************************************************/
void VGA_InitDMA() {

/* Variable declarations for DMAshift */
    uint8 DMAshift_Chan;

/* DMA Configuration for DMA_ShiftLoad */
    DMAshift_Chan = DMAshift_DmaInitialize(DMA_VGA_Line_BYTES_PER_BURST, DMA_VGA_Line_REQUEST_PER_BURST, 
        HI16(DMA_VGA_Line_SRC_BASE), HI16(DMA_VGA_Line_DST_BASE));
    DMA_VGA_Line_TD[0] = CyDmaTdAllocate();
    CyDmaTdSetConfiguration(DMA_VGA_Line_TD[0], ACT_PIXELS / 8, DMA_VGA_Line_TD[0], CY_DMA_TD_INC_SRC_ADR | DMAshift__TD_TERMOUT_EN);
    CyDmaTdSetAddress(DMA_VGA_Line_TD[0], LO16((uint32)&scrn.scn_pix), LO16((uint32)VGAgen_dp_shift_F0_PTR));
    CyDmaChSetInitialTd(DMAshift_Chan, DMA_VGA_Line_TD[0]);
    CyDmaChEnable(DMAshift_Chan, 1); // Do not destroy TD !
}

/*******************************************************************************
* Function Name: VideoFrame
********************************************************************************
*
* Summary: this routine is called from the VideoLine interrupt every time
*          a new frame starts. This takes care of the blinking of the cursor
*          and calls a user defined function to trigger other activity.
*          This routine should be as short a possible, because it is run
*          from within interrupt context.
*
* Return: none
*
********************************************************************************/
void VideoFrame() {
    scn_mask = 0xffffffff; // Set all bits
    frame_count++;
}

/*******************************************************************************
* Function Name: ScreenFrameAction
********************************************************************************
*
* Summary: This routine is called in the main loop.
*          It allows to run some action, defined by the scn_fh() on every
*          frame interrupt. Putting it here will make the interrupt routine
*          shorter.
*
* Return: none
*
********************************************************************************/
void ScreenFrameAction() {
    if (scrn.scn_fh == NULL) return;

    if (scn_mask & FRAME_MASK) {
        scn_mask &= ~FRAME_MASK;
        scrn.scn_fh();
    }
}

/*******************************************************************************
* Function Name: VideoLineInterrupt
********************************************************************************
*
* Summary: This is the interrupt routine that is called at the start of a new
*          horizontal video line. It is called every 14.8 μs. Horizontal sync
*          pulses are generated by the UDB hardware block, but vertical sync
*          pulses are handled by this routine. A new hardware address has to
*          be assigned to the DMA block. However we will duplicate each horizontal
*          line, so the address changes only once every 2 vertical lines.
*          This can be changed with the parameter VERT_SCALING.
*
* Return: none
*
********************************************************************************/
// Called from DMA interrupt handler: LoadLine
// Runs every 14.8 μs
CY_ISR( VideoLineInterrupt ) {
    uint8 control = H_POL ? 0 : (1<<H_POL_BIT);
    uint8 vsync = 0;
       
    cur_line++;
    if ( cur_line >= TOT_LINES) { // Start Back Porch, new frame
        cur_line = 0;
        VideoFrame();
    } else
    if ( cur_line >= (TOT_LINES - SYNC_V) ) { // Vert Synch
        vsync = 1;
    } else
    if ( (cur_line >= BACK_PORCH_V) && (cur_line < ACT_LINES + BACK_PORCH_V ) ) { // Active line
        disp_line = cur_line - BACK_PORCH_V;
        if ( (disp_line % VERT_SCALING) == 0) {
            CyDmaTdSetAddress(DMA_VGA_Line_TD[0], LO16((uint32)&scrn.scn_pix[disp_line * scrn.scn_wpl / VERT_SCALING ]), 
                LO16((uint32)VGAgen_dp_shift_F0_PTR));
        }
        control |= 1<<ACTIVE_BIT;
    }
    control |= vsync ? (V_POL ? (1<<V_POL_BIT) : 0)      : (V_POL ? 0 : (1<<V_POL_BIT));
    control &= vsync ? (V_POL ? 0xff : ~(1<<V_POL_BIT) ) : (V_POL ? ~(1<<V_POL_BIT) : 0xff);
    ActiveLine_Write(control);
}

/*******************************************************************************
* Function Name: ScreenInit
********************************************************************************
*
* Summary:
*  Initialises the VGA screen.
*
* Parameters:
*  pix: pointer an array of words containing the pixels: each pixel is one bit.
*  w:   width of the screen in pixels
*  h:   height of the screen in pixels
*  FrameHandler: pointer to a function that is called at each frame change,
*                that is 60 times per second.
*
* Return: none
*
*******************************************************************************/
void ScreenInit(uint16_t *pix, uint16_t w, uint16_t h, void (*FrameHandler)() ) {
    VGA_InitDMA();
    VGA_Line_ISR_StartEx(VideoLineInterrupt);

    scrn.scn_w = w;
    scrn.scn_h = h;
    scrn.scn_wpl = (w % 16) ? 1 + w / 16 : w / 16;
    scrn.scn_bbp = 1;
    scrn.scn_pix = pix;
    scrn.scn_fh  = FrameHandler;
}

/*******************************************************************************
* Function Name: ScreenClear
********************************************************************************
*
* Summary: Erases the screen, using foreground or background color
*
* Parameters:
*  color: currently 0 or 1. (0 is background color, 1 foreground)
*
* Return: none
*
*******************************************************************************/
void ScreenClear(uint8 color) {
    int val = 0;
    if (color > 0) val = 0xffff;
    memset(scrn.scn_pix, val, 2 * scrn.scn_wpl * scrn.scn_h);
}

/*******************************************************************************
* Function Name: ScreenSetColor2
********************************************************************************
*
* Summary: Sets foreground and background color. Because of limited ram memory
*          pixel size is only one bit. However, 3 pins are used to connect to
*          each of the vga colors (RGB). Therefore it is possible to choose
*          between 6 colors, plus black and white.
*
* Parameters:
*  fg: foreground color, when pixel is 1. (0x04 is red, 0x02 is green, 0x01 is blue)
*  bg: background color, when pixel is 0.
*
* Return: none
*
*******************************************************************************/
void ScreenSetColor2(uint8_t fg, uint8_t bg) {
    
    RGB_fg_Write(fg);
    RGB_bg_Write(bg);
}

/*******************************************************************************
* Function Name: ScreenSetColor
********************************************************************************
*
* Summary: Same as ScreenSetColor2, but foreground and background are packed
*          into a single color value.
*
* Parameters:
*  col: bit 6-4 defines the foreground color. bit 2-0 define the background color.
*
* Return: none
*
*******************************************************************************/
void ScreenSetColor(uint8_t col) {
    RGB_fg_Write(col >> 4);
    RGB_bg_Write(col & 0x07);
}

/*******************************************************************************
* Function Name: ScreenWritePixel
********************************************************************************
*
* Summary: Sets or clears a single pixel.
*
* Parameters:
*  x: horizontal position, 0 is left
*  y: vertical position, 0 is top of the screen
*
* Return: none
*
*******************************************************************************/
void ScreenWritePixel(int16_t x, int16_t y, uint16_t color) {
    if ((x < 0) || (y < 0) || (x >= scrn.scn_w) || (y >= scrn.scn_h)) return;
    
    uint16_t pixdata = 0x8000;
    
    pixdata >>= (x % PIX_PER_WORD);
    
    if (color > 0)
        scrn.scn_pix[x / 16 + y * scrn.scn_wpl] |= pixdata;
    else 
        scrn.scn_pix[x / 16 + y * scrn.scn_wpl] &= ~pixdata;
}

/*******************************************************************************
* Function Name: ScreenReadPixel
********************************************************************************
*
* Summary: reads the value of a single pixel.
*
* Parameters:
*  x: horizontal position, 0 is left
*  y: vertical position, 0 is top of the screen
*
* Return: 1 if set, 0 if not set
*
*******************************************************************************/
uint8_t ScreenReadPixel(int16_t x, int16_t y) {
    uint16_t pixdata = 0x8000 >> (x % PIX_PER_WORD);
    
    return (scrn.scn_pix[x / 16 + y * scrn.scn_wpl] & pixdata) ? 1 : 0 ;
}

/*******************************************************************************
* Function Name: ScreenTogglePixel
********************************************************************************
*
* Summary: Toggles a single pixel
*
* Parameters:
*  x: horizontal position, 0 is left
*  y: vertical position, 0 is top of the screen
*
* Return: none
*
*******************************************************************************/
void ScreenTogglePixel(int16_t x, int16_t y) {
    if ((x < 0) || (y < 0) || (x >= scrn.scn_w) || (y >= scrn.scn_h)) return;
    
    uint16_t pixdata = 0x8000;
    uint16_t pixval;
    
    pixdata >>= (x % PIX_PER_WORD);
    
    pixval = scrn.scn_pix[x / 16 + y * scrn.scn_wpl] & pixdata;
    
    if (pixval == 0)
        scrn.scn_pix[x / 16 + y * scrn.scn_wpl] |= pixdata;
    else 
        scrn.scn_pix[x / 16 + y * scrn.scn_wpl] &= ~pixdata;
}

/*******************************************************************************
* Function Name: ScreenScroll
********************************************************************************
*
* Summary: Scrolls the whole screen up or down. The last line(s) are erased.
*
* Parameters:
*  num: lines to scroll, positive is up, negative is down.
*
* Return: none
*
*******************************************************************************/
void ScreenScroll(int16_t num) {
    if (num > 0) {
        for (uint16 k = num; k < SCREEN_H; k++)
            memcpy(&scrn.scn_pix[(k - num) * scrn.scn_wpl], &scrn.scn_pix[k * scrn.scn_wpl], scrn.scn_wpl);
        memset(&scrn.scn_pix[scrn.scn_wpl * (SCREEN_H - num)], 0, num * scrn.scn_wpl);
    }
    if (num < 0) {
        for (uint16 k = SCREEN_H - num; k >= 0; k--)
            memcpy(&scrn.scn_pix[(k + num) * scrn.scn_wpl], &scrn.scn_pix[k * scrn.scn_wpl], scrn.scn_wpl);
        memset(&scrn.scn_pix[scrn.scn_wpl * SCREEN_H], 0, num * scrn.scn_wpl);
    }
}

/*******************************************************************************
* Function Name: ScreenDrawHorLine
********************************************************************************
*
* Summary: Draw a horizontal line
*
* Parameters:
*  x: horizontal starting position
*  y: vertical starting position
*  w: length
*  col: if col > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenDrawHorLine(int16_t x, int16_t y, int16_t w, uint16_t color) {
    if (y >= scrn.scn_h || y < 0) return;
    if (x + w >= scrn.scn_w) w = scrn.scn_w - x;
    if (w < 20) {
        for (uint16 p = x; p < x + w; p++) ScreenWritePixel(p, y, color); 
    } else { // much more complex, but faster if many pixels must be changed
        uint8_t  x_rem_left  = x & 15;
        uint8_t  x_rem_right = (x + w) & 15;
        uint16_t xl_word = (x_rem_left) ? x / 16 + 1 : x / 16;
        uint16_t xr_word = (x + w) / 16;
        uint16_t pixmask_l, pixmask_r;
        uint16_t words_x = xr_word - xl_word; // words on same line to set/reset
        
        pixmask_l = 0xffff >> x_rem_left;
        pixmask_r = 0xffff << (16 - x_rem_right);

        if (color) {
            if (x_rem_left) scrn.scn_pix[xl_word - 1 + scrn.scn_wpl * y] |= pixmask_l;
            memset(&scrn.scn_pix[xl_word + scrn.scn_wpl * y], 0xff, 2 * words_x);
            if (x_rem_right) scrn.scn_pix[xl_word + words_x + y * scrn.scn_wpl] |= pixmask_r;
        } else {
            if (x_rem_left) scrn.scn_pix[xl_word - 1 + scrn.scn_wpl * y] &= ~pixmask_l;
            memset(&scrn.scn_pix[xl_word + scrn.scn_wpl * y], 0, 2 * words_x);
            if (x_rem_right) scrn.scn_pix[xl_word + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
        }

    }
}

/*
void ScreenDrawHorLineSlow(int16_t x, int16_t y, int16_t w, uint16_t color) {
    if (y >= scrn.scn_h || y < 0) return;
    if (x + w >= scrn.scn_w) w = scrn.scn_w - x;
    for (uint16 p = x; p < x + w; p++) ScreenWritePixel(p, y, color); 
}
*/

/*******************************************************************************
* Function Name: ScreenDrawVertLine
********************************************************************************
*
* Summary: Draw a vertical line
*
* Parameters:
*  x: horizontal starting position
*  y: vertical starting position
*  h: vertical length
*  col: if col > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenDrawVertLine(int16_t x, int16_t y, int16_t h, uint16_t color) {
    if (x < 0 || x >= scrn.scn_w) return;
    if (y + h >= scrn.scn_h) h = scrn.scn_h - y;
    for (uint16 p = y; p < y + h; p++) ScreenWritePixel(x, p, color); 
}

/*******************************************************************************
* Function Name: ScreenWriteLine
********************************************************************************
*
* Summary: Draw a line between 2 points using Bresenham's algorithm
*
* Parameters:
*    x0  Start point x coordinate
*    y0  Start point y coordinate
*    x1  End point x coordinate
*    y1  End point y coordinate
*    color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenWriteLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color) {
  int16_t steep = abs(y1 - y0) > abs(x1 - x0);
  if (steep) {
    _swap_int16_t(x0, y0);
    _swap_int16_t(x1, y1);
  }

  if (x0 > x1) {
    _swap_int16_t(x0, x1);
    _swap_int16_t(y0, y1);
  }

  int16_t dx, dy;
  dx = x1 - x0;
  dy = abs(y1 - y0);

  int16_t err = dx / 2;
  int16_t ystep;

  if (y0 < y1) {
    ystep = 1;
  } else {
    ystep = -1;
  }

  for (; x0 <= x1; x0++) {
    if (steep) {
      ScreenWritePixel(y0, x0, color);
    } else {
      ScreenWritePixel(x0, y0, color);
    }
    err -= dy;
    if (err < 0) {
      y0 += ystep;
      err += dx;
    }
  }
}

/*******************************************************************************
* Function Name: ScreenFillRect
********************************************************************************
*
* Summary: Draw a filled rectangle, given the upper left starting point and
*          the height and width of the rectangle.
*
* Parameters:
*    x   Start point x coordinate
*    y   Start point y coordinate
*    w   Horizontal width
*    h   Vertical height
*    color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/                            
void ScreenFillRect(int16_t x, int16_t y, uint16_t w, uint16_t h, uint16_t color) {
    for (uint16_t i = y; i < y + h; i++) {
        ScreenDrawHorLine(x, i, w, color);
    }
}

/*******************************************************************************
* Function Name: ScreenDrawCircle
********************************************************************************
*
* Summary: Draw a filled rectangle, given the upper left starting point and
*          the height and width of the rectangle.
*
* Parameters:
*    x0   Center-point x coordinate
*    y0   Center-point y coordinate
*    r    Circle radius
*    color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/ 
void ScreenDrawCircle(int16_t x0, int16_t y0, uint16_t r, uint16_t color) {

  int16_t f = 1 - r;
  int16_t ddF_x = 1;
  int16_t ddF_y = -2 * r;
  int16_t x = 0;
  int16_t y = r;

  ScreenWritePixel(x0, y0 + r, color);
  ScreenWritePixel(x0, y0 - r, color);
  ScreenWritePixel(x0 + r, y0, color);
  ScreenWritePixel(x0 - r, y0, color);

  while (x < y) {
    if (f >= 0) {
      y--;
      ddF_y += 2;
      f += ddF_y;
    }
    x++;
    ddF_x += 2;
    f += ddF_x;

    ScreenWritePixel(x0 + x, y0 + y, color);
    ScreenWritePixel(x0 - x, y0 + y, color);
    ScreenWritePixel(x0 + x, y0 - y, color);
    ScreenWritePixel(x0 - x, y0 - y, color);
    ScreenWritePixel(x0 + y, y0 + x, color);
    ScreenWritePixel(x0 - y, y0 + x, color);
    ScreenWritePixel(x0 + y, y0 - x, color);
    ScreenWritePixel(x0 - y, y0 - x, color);
  }
}

/*******************************************************************************
* Function Name: ScreenDrawRect
********************************************************************************
*   Summary:   Draw a rectangle with no fill color
*
*   Parameters:
*      x   Top left corner x coordinate
*      y   Top left corner y coordinate
*      w   Width in pixels
*      h   Height in pixels
*      color: if color > 0, foreground else background
*
* Return: none
*
*******************************************************************************/
void ScreenDrawRect(int16_t x, int16_t y, int16_t w, int16_t h,
                            uint16_t color) {
  ScreenDrawHorLine(x, y, w, color);
  ScreenDrawHorLine(x, y + h - 1, w, color);
  ScreenDrawVertLine(x, y, h, color);
  ScreenDrawVertLine(x + w - 1, y, h, color);
}

/*******************************************************************************
* Function Name: ScreenDrawChar
********************************************************************************
*
* Summary:
*    Takes a null terminated string and writes it on the screen starting at the
*    current cursor position.
*    Advances the cursor and wraps on a new line is required.
*
* Parameters:
*    c:   Character to display
*
* Return: none
*
*******************************************************************************/
// Draw a character
/**************************************************************************/
/*!
    @brief   Draw a single character using screen coordinates
    @param    x   Bottom left corner x coordinate
    @param    y   Bottom left corner y coordinate
    @param    uc  The 16-bit unicode character
    @param    fnt pointer to font struct
    @param    color 16-bit 5-6-5 Color to draw character with
    @param    bg 16-bit 5-6-5 Color to fill background with (if same as color,
              no background)
    @param    size_x  Font magnification level in X-axis, 1 is 'original' size
    @param    size_y  Font magnification level in Y-axis, 1 is 'original' size
*/
/**************************************************************************/
void ScreenDrawChar(int16_t x, int16_t y, uint8 ac, ScreenFont *fnt,
                            uint16_t color, uint16_t bg, uint8_t size_x,
                            uint8_t size_y) {
                                
                                
    if (fnt) {   
        uint8_t w,h;
        uint16_t glyph;
                                    
        glyph = fnt->ac2glyph(ac);
        
        if (glyph == 0xffff) return; // Glyph not present
        
        w = fnt->width;
        h = fnt->height;
        
        for (int8_t i = 0; i < h; i++) {
            uint8_t line = fnt->bitmap[glyph * h + i];
            for (int8_t j = 0; j < w; j++, line <<= 1) {
                if (line & 0x80) {
                    if (size_x == 1 && size_y == 1)
                        ScreenWritePixel(x + j, y + i, color);
                    else
                        ScreenFillRect(x + j * size_x, y + i * size_y, size_x, size_y,
                          color);
                } else if (bg != color) {
                    if (size_x == 1 && size_y == 1)
                        ScreenWritePixel(x + j, y + i, bg);
                    else
                        ScreenFillRect(x + j * size_x, y + i * size_y, size_x, size_y, bg);
                }
            }
        }
    }
    
}

/* [] END OF FILE */
