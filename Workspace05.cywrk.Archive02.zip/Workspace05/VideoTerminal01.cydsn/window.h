/* ========================================
 *
 * Copyright (C) 2022 by Pieter Vandevoorde
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * ========================================
*/
#include "stdint.h"
#include "screen.h"

#ifndef WINDOW_H
#define WINDOW_H

typedef enum _scroll { SCRL_NONE, SCRL_SCRL, SCRL_WRAP } eScroll;
typedef enum _windir { W_LEFT, W_RIGHT, W_UP, W_DOWN } eWindir;
typedef enum _cursor { C_NONE, C_UNDERL, C_BLOCK } eCurType;
    
typedef struct Window {
    /* Screen related */
    uint16_t  orig_x;      // x origin in pixels relative to screen
    uint16_t  orig_y;      // y origin in pixels relative to screen
    uint16_t  w_x;         // x width in pixels
    uint16_t  w_y;         // y width in pixels
    uint8_t   border;      // border in pixels         
    eCurType  cursor_type; // cursor type: 0 off, 1 underscore, 2 reverse video
    uint8_t   rotation;    // Display rotation (0 thru 3) - not used
    /* Text related */
    uint16_t  cursor_x, cursor_y; // Text cursor position in pixels relative to window
    ScreenFont *fnt;
    uint8_t   fnt_x, fnt_y;       // Font bounding box
    uint16_t  textcolor,     ///< 16-bit text color for print()
              textbgcolor;   ///< 16-bit background color for print()
    uint8_t   textsize_x,     ///< Desired magnification in X-axis of text to print()
              textsize_y;     ///< Desired magnification in Y-axis of text to print()
    uint8_t   bb_x;         // Text Bounding box in X   
    uint8_t   bb_y;         // Text Bounding box in Y
    uint8_t   nch_x, nch_y; // Number of characters in x and y direction
    uint8_t   wrap_x;       // wrap left
    uint8_t   tabstop;
    uint8_t   scroll_up;
    uint8_t   scroll_dwn;
    
} Window;

void WindowInit(Window *win, uint16_t x_orig, uint16_t y_orig, uint16_t width, uint16_t height, ScreenFont *fnt, eCurType curMode);
void WindowStart(Window *win);
void WindowSetFont(Window *win, ScreenFont *font);
void WindowSetTextSize(Window *win, uint8_t size_x, uint8_t size_y);
void WindowSetMode(Window *win, eCurType mode);
void WindowSetCursor(Window *win, uint16_t x, uint16_t y);
uint8_t WindowSetCursorRel(Window *win, int16_t dx, int16_t dy);
void WindowMoveCursor(Window *win, eWindir dir, uint8_t count);
void WindowShowFont(Window *win);
void WindowWrite(Window *win, uint8_t ac, uint8_t inv);
void WindowWriteString(Window *win, char *str, uint8_t inv);
void WindowScroll(Window *win, int16_t num);
void WindowBlinkCursor(Window *win, uint16_t f);
void WindowClear(Window *win, uint8_t color);

#endif // WINDOW_H

/* [] END OF FILE */
