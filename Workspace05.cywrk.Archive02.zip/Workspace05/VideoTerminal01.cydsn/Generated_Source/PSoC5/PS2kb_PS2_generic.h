/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#if !defined(PS2_generic_H)
#define PS2_generic_H
typedef struct kb_info {
    uint8_t (* fp_scan)(struct kb_info *kb, uint8_t);
    uint8_t *asciimap;
    uint8_t scanset;
    uint8_t prev_code, keyb_status, keyb_modifiers, keyb_lock_status;
    uint8_t last_sent;
};
#endif
/* [] END OF FILE */
