/*******************************************************************************
* File Name: KeybRdy.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_KeybRdy_H) /* Pins KeybRdy_H */
#define CY_PINS_KeybRdy_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "KeybRdy_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 KeybRdy__PORT == 15 && ((KeybRdy__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    KeybRdy_Write(uint8 value);
void    KeybRdy_SetDriveMode(uint8 mode);
uint8   KeybRdy_ReadDataReg(void);
uint8   KeybRdy_Read(void);
void    KeybRdy_SetInterruptMode(uint16 position, uint16 mode);
uint8   KeybRdy_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the KeybRdy_SetDriveMode() function.
     *  @{
     */
        #define KeybRdy_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define KeybRdy_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define KeybRdy_DM_RES_UP          PIN_DM_RES_UP
        #define KeybRdy_DM_RES_DWN         PIN_DM_RES_DWN
        #define KeybRdy_DM_OD_LO           PIN_DM_OD_LO
        #define KeybRdy_DM_OD_HI           PIN_DM_OD_HI
        #define KeybRdy_DM_STRONG          PIN_DM_STRONG
        #define KeybRdy_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define KeybRdy_MASK               KeybRdy__MASK
#define KeybRdy_SHIFT              KeybRdy__SHIFT
#define KeybRdy_WIDTH              1u

/* Interrupt constants */
#if defined(KeybRdy__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in KeybRdy_SetInterruptMode() function.
     *  @{
     */
        #define KeybRdy_INTR_NONE      (uint16)(0x0000u)
        #define KeybRdy_INTR_RISING    (uint16)(0x0001u)
        #define KeybRdy_INTR_FALLING   (uint16)(0x0002u)
        #define KeybRdy_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define KeybRdy_INTR_MASK      (0x01u) 
#endif /* (KeybRdy__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define KeybRdy_PS                     (* (reg8 *) KeybRdy__PS)
/* Data Register */
#define KeybRdy_DR                     (* (reg8 *) KeybRdy__DR)
/* Port Number */
#define KeybRdy_PRT_NUM                (* (reg8 *) KeybRdy__PRT) 
/* Connect to Analog Globals */                                                  
#define KeybRdy_AG                     (* (reg8 *) KeybRdy__AG)                       
/* Analog MUX bux enable */
#define KeybRdy_AMUX                   (* (reg8 *) KeybRdy__AMUX) 
/* Bidirectional Enable */                                                        
#define KeybRdy_BIE                    (* (reg8 *) KeybRdy__BIE)
/* Bit-mask for Aliased Register Access */
#define KeybRdy_BIT_MASK               (* (reg8 *) KeybRdy__BIT_MASK)
/* Bypass Enable */
#define KeybRdy_BYP                    (* (reg8 *) KeybRdy__BYP)
/* Port wide control signals */                                                   
#define KeybRdy_CTL                    (* (reg8 *) KeybRdy__CTL)
/* Drive Modes */
#define KeybRdy_DM0                    (* (reg8 *) KeybRdy__DM0) 
#define KeybRdy_DM1                    (* (reg8 *) KeybRdy__DM1)
#define KeybRdy_DM2                    (* (reg8 *) KeybRdy__DM2) 
/* Input Buffer Disable Override */
#define KeybRdy_INP_DIS                (* (reg8 *) KeybRdy__INP_DIS)
/* LCD Common or Segment Drive */
#define KeybRdy_LCD_COM_SEG            (* (reg8 *) KeybRdy__LCD_COM_SEG)
/* Enable Segment LCD */
#define KeybRdy_LCD_EN                 (* (reg8 *) KeybRdy__LCD_EN)
/* Slew Rate Control */
#define KeybRdy_SLW                    (* (reg8 *) KeybRdy__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define KeybRdy_PRTDSI__CAPS_SEL       (* (reg8 *) KeybRdy__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define KeybRdy_PRTDSI__DBL_SYNC_IN    (* (reg8 *) KeybRdy__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define KeybRdy_PRTDSI__OE_SEL0        (* (reg8 *) KeybRdy__PRTDSI__OE_SEL0) 
#define KeybRdy_PRTDSI__OE_SEL1        (* (reg8 *) KeybRdy__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define KeybRdy_PRTDSI__OUT_SEL0       (* (reg8 *) KeybRdy__PRTDSI__OUT_SEL0) 
#define KeybRdy_PRTDSI__OUT_SEL1       (* (reg8 *) KeybRdy__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define KeybRdy_PRTDSI__SYNC_OUT       (* (reg8 *) KeybRdy__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(KeybRdy__SIO_CFG)
    #define KeybRdy_SIO_HYST_EN        (* (reg8 *) KeybRdy__SIO_HYST_EN)
    #define KeybRdy_SIO_REG_HIFREQ     (* (reg8 *) KeybRdy__SIO_REG_HIFREQ)
    #define KeybRdy_SIO_CFG            (* (reg8 *) KeybRdy__SIO_CFG)
    #define KeybRdy_SIO_DIFF           (* (reg8 *) KeybRdy__SIO_DIFF)
#endif /* (KeybRdy__SIO_CFG) */

/* Interrupt Registers */
#if defined(KeybRdy__INTSTAT)
    #define KeybRdy_INTSTAT            (* (reg8 *) KeybRdy__INTSTAT)
    #define KeybRdy_SNAP               (* (reg8 *) KeybRdy__SNAP)
    
	#define KeybRdy_0_INTTYPE_REG 		(* (reg8 *) KeybRdy__0__INTTYPE)
#endif /* (KeybRdy__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_KeybRdy_H */


/* [] END OF FILE */
