/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "PS2kb_1.h"
#include "PS2kb_1_B_PS2kb_defs.h"
#include "PS2kb_1_B_PS2kb_kb_status.h"

/*******************************************************************************
* Function Name: PS2kb_1_Init
********************************************************************************
*
* Summary:
*  Initialise the component
*
* Parameters:
*  Pointer to keyboard structure.
*
* Return:
*  Current scanset
*

*******************************************************************************/
uint8_t PS2kb_1_Init(Keyboard *kb) {
    kb->prev_code   = 0;
    kb->keyb_status = 0;
    kb->keyb_modifiers = 0;
    kb->keyb_lock_status = 0;
    kb->read  = PS2kb_1_GetScancode;
    kb->write = PS2kb_1_Send;
    kb->status = PS2kb_1_GetStatus;
    
    return KeybSetScanset(kb, 0);
}


/*******************************************************************************
* Function Name: PS2kb_1_GetScancode
********************************************************************************
*
* Summary:
*  Read the scancode from the keyboard
*
* Parameters:
*  None.
*
* Return:
*  The next byte of data read from the FIFO.
*

*******************************************************************************/
uint16_t PS2kb_1_GetScancode(void) 
{
    uint16_t scancode = *(PS2kb_1_B_PS2kb_kb_dp_F1_PTR);
    
    return scancode;
}

/*******************************************************************************
* Function Name: PS2kb_1_GetStatus
********************************************************************************
*
* Summary:
*  Read the status from the UDB block. Wrapper around status register.
*  F0 is the transmit Fifo (Host -> Keyboard)
*  F1 is the receive Fifo  (Keyboard -> Host)
*
* Parameters:
*  None.
*
* Return:
*  Status byte:
*  bit 0: F1 not empty
*  bit 1: F1 full
*  bit 2: F0 empty
*  bit 3: F0 not full
*  bit 4: Keyboard acknowledge bit (set when keyboard acknowledges transmission coming from host)
*  bit 5: End of transmission Host->Device
*  bit 6: Byte from keyboard is available in F1.
*  Bit 4-6 are sticky bits, they can be used to generate an interrupt and will be cleared
*          when reading the status register.
*******************************************************************************/
uint8_t  PS2kb_1_GetStatus(void)
{
    return PS2kb_1_B_PS2kb_kb_status_Read();
}

/*******************************************************************************
* Function Name: CheckParity
********************************************************************************
*
* Summary:
*  takes the byte and transforms it in a code to insert in the keyboard fifo
*  function has static scope, so no need to prefix it.
*
* Parameters:
*  val the word to test
*
* Return:
*  0 if even, 1 if odd
*
*******************************************************************************/
static uint8_t CheckParity(uint16_t val) {
    uint8_t par = 0;
    while (val > 0) {
        if (val & 1) par++;
        val >>= 1;
    }
    return (par & 1);
}

/*******************************************************************************
* Function Name: PS2kb_1_Send
********************************************************************************
*
* Summary:
*  takes the byte and transforms it in a code to insert in the keyboard fifo
*
* Parameters:
*  val the byte to transmit to the keyboard
*
* Return:
*  0 when acknowledge bit was set by keyboard
*  1 if not set (error)
*
*******************************************************************************/
uint8_t PS2kb_1_Send(uint8_t val) {
    
    uint8_t parity = CheckParity(val);
    uint8_t status = 0;
    
    uint16_t code = (uint16_t)val;
    code = (code << 1) | 0x400;// Add start and stop bit
    code |= parity ? 0 : 0x200; // Must have odd parity (without stop bit)
    
    while ( (PS2kb_1_B_PS2kb_kb_status_Read() & 4) == 0) {} // wait until f0 is empty
    //while ( (PS2kb_1_PS2keyb_kb_status_Read() & 8) == 0) {} // wait until f0 is not full
    
    CY_SET_REG16(PS2kb_1_B_PS2kb_kb_dp_F0_PTR, code);
    
    while ( (status & 0x20) == 0)
        status = PS2kb_1_B_PS2kb_kb_status_Read();
    
    return (status & 0x10) ? 0 : 1;
}

/* [] END OF FILE */
