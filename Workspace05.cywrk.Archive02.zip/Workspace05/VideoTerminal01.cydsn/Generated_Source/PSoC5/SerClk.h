/*******************************************************************************
* File Name: SerClk.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_SerClk_H)
#define CY_CLOCK_SerClk_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
* Conditional Compilation Parameters
***************************************/

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component cy_clock_v2_20 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*        Function Prototypes
***************************************/

void SerClk_Start(void) ;
void SerClk_Stop(void) ;

#if(CY_PSOC3 || CY_PSOC5LP)
void SerClk_StopBlock(void) ;
#endif /* (CY_PSOC3 || CY_PSOC5LP) */

void SerClk_StandbyPower(uint8 state) ;
void SerClk_SetDividerRegister(uint16 clkDivider, uint8 restart) 
                                ;
uint16 SerClk_GetDividerRegister(void) ;
void SerClk_SetModeRegister(uint8 modeBitMask) ;
void SerClk_ClearModeRegister(uint8 modeBitMask) ;
uint8 SerClk_GetModeRegister(void) ;
void SerClk_SetSourceRegister(uint8 clkSource) ;
uint8 SerClk_GetSourceRegister(void) ;
#if defined(SerClk__CFG3)
void SerClk_SetPhaseRegister(uint8 clkPhase) ;
uint8 SerClk_GetPhaseRegister(void) ;
#endif /* defined(SerClk__CFG3) */

#define SerClk_Enable()                       SerClk_Start()
#define SerClk_Disable()                      SerClk_Stop()
#define SerClk_SetDivider(clkDivider)         SerClk_SetDividerRegister(clkDivider, 1u)
#define SerClk_SetDividerValue(clkDivider)    SerClk_SetDividerRegister((clkDivider) - 1u, 1u)
#define SerClk_SetMode(clkMode)               SerClk_SetModeRegister(clkMode)
#define SerClk_SetSource(clkSource)           SerClk_SetSourceRegister(clkSource)
#if defined(SerClk__CFG3)
#define SerClk_SetPhase(clkPhase)             SerClk_SetPhaseRegister(clkPhase)
#define SerClk_SetPhaseValue(clkPhase)        SerClk_SetPhaseRegister((clkPhase) + 1u)
#endif /* defined(SerClk__CFG3) */


/***************************************
*             Registers
***************************************/

/* Register to enable or disable the clock */
#define SerClk_CLKEN              (* (reg8 *) SerClk__PM_ACT_CFG)
#define SerClk_CLKEN_PTR          ((reg8 *) SerClk__PM_ACT_CFG)

/* Register to enable or disable the clock */
#define SerClk_CLKSTBY            (* (reg8 *) SerClk__PM_STBY_CFG)
#define SerClk_CLKSTBY_PTR        ((reg8 *) SerClk__PM_STBY_CFG)

/* Clock LSB divider configuration register. */
#define SerClk_DIV_LSB            (* (reg8 *) SerClk__CFG0)
#define SerClk_DIV_LSB_PTR        ((reg8 *) SerClk__CFG0)
#define SerClk_DIV_PTR            ((reg16 *) SerClk__CFG0)

/* Clock MSB divider configuration register. */
#define SerClk_DIV_MSB            (* (reg8 *) SerClk__CFG1)
#define SerClk_DIV_MSB_PTR        ((reg8 *) SerClk__CFG1)

/* Mode and source configuration register */
#define SerClk_MOD_SRC            (* (reg8 *) SerClk__CFG2)
#define SerClk_MOD_SRC_PTR        ((reg8 *) SerClk__CFG2)

#if defined(SerClk__CFG3)
/* Analog clock phase configuration register */
#define SerClk_PHASE              (* (reg8 *) SerClk__CFG3)
#define SerClk_PHASE_PTR          ((reg8 *) SerClk__CFG3)
#endif /* defined(SerClk__CFG3) */


/**************************************
*       Register Constants
**************************************/

/* Power manager register masks */
#define SerClk_CLKEN_MASK         SerClk__PM_ACT_MSK
#define SerClk_CLKSTBY_MASK       SerClk__PM_STBY_MSK

/* CFG2 field masks */
#define SerClk_SRC_SEL_MSK        SerClk__CFG2_SRC_SEL_MASK
#define SerClk_MODE_MASK          (~(SerClk_SRC_SEL_MSK))

#if defined(SerClk__CFG3)
/* CFG3 phase mask */
#define SerClk_PHASE_MASK         SerClk__CFG3_PHASE_DLY_MASK
#endif /* defined(SerClk__CFG3) */

#endif /* CY_CLOCK_SerClk_H */


/* [] END OF FILE */
