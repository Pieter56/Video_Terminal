/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "terminal.h"

#ifndef MENU_H
#define MENU_H
    
typedef struct _menu {
    uint8_t items, item_len;
    struct _menu *(*submenu)[];
    char *values[];
} Menu;

uint8_t MenuShowMain(Terminal *tm, Menu *main, uint8_t sel, uint8_t level);
void MenuShowSub(Window *win, Menu *sub_menu, uint8_t sel1, uint8_t erase, int16_t offset_x, int16_t offset_y);

#endif
/* [] END OF FILE */
