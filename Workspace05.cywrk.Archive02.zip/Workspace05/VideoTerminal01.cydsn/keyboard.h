/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "stdint.h"

#ifndef KEYBOARD_H
#define KEYBOARD_H

// Modifiers bits used in USB HID report
#define KEY_LEFT_CTRL     1
#define KEY_LEFT_SHIFT    2
#define KEY_LEFT_ALT      4
#define KEY_LEFT_WIN      8
#define KEY_RIGHT_CTRL    16
#define KEY_RIGHT_SHIFT   32
#define KEY_RIGHT_ALT     64
#define KEY_RIGHT_WIN     128

#define KEYB_MODIF       1
#define KEYB_CTRL        2
#define KEYB_EXTENDED    4
#define KEYB_RELEASE     8
#define KEYB_MODIF_USED 16

#define KEYB_PRESSED  1
#define KEYB_LOCK_ACT 2

/* Bits for indicator lights */
#define KEYB_SCROLL_LOCK_SHIFT  (0x00u)
#define KEYB_NUM_LOCK_SHIFT     (0x01u)
#define KEYB_CAPS_LOCK_SHIFT    (0x02u)
#define KEYB_SCROLL_LOCK    (uint8)(0x01u << KEYB_SCROLL_LOCK_SHIFT)
#define KEYB_NUM_LOCK       (uint8)(0x01u << KEYB_NUM_LOCK_SHIFT)
#define KEYB_CAPS_LOCK      (uint8)(0x01u << KEYB_CAPS_LOCK_SHIFT)

typedef struct _dead_key_translation {
    const uint8_t *key_orig;
    const uint8_t *key_accent;
} sDeadKeyXlate;

typedef struct _dict_dkey {
    const uint16_t       dk_index;
    const sDeadKeyXlate  *dk_xlate;
} sDictDkey;

typedef struct _keyboard {
    uint8_t (* fp_scan)(struct _keyboard *kb, uint8_t);
    uint16_t (* read)(void);
    uint8_t (* write)(uint8_t ch);
    uint8_t (* status)(void);
    uint8_t *kb_layout;
    sDictDkey     *dk_xlate;
    sDeadKeyXlate *xlate_info;
    uint16_t dead_key;
    uint8_t scanset;
    uint8_t newline;
    uint8_t prev_code, keyb_status, keyb_modifiers, keyb_lock_status;
    uint8_t last_sent;
} Keyboard;

uint8_t KeybSetScanset(Keyboard *kb, uint8_t *sc_val);
void    KeybSetLayout(Keyboard *kb, uint8_t layout);
void    KeybInit(Keyboard *kb);
void    KeybReset(Keyboard *kb);
uint8_t KeybSend(Keyboard *kb, uint8_t val);
uint8_t KeybResend(Keyboard *kb);
uint8_t KeybUpdateLeds(Keyboard *kb);
uint8_t KeybLock(Keyboard *kb, uint8_t lock, uint8_t pressed);
void    KeybSetModifiers(Keyboard *kb, uint8_t code, uint8_t make);
uint8_t KeybGetModifiers(Keyboard *kb);
uint8_t KeybScanset1(Keyboard *kb, uint8_t code);
uint8_t KeybScanset2(Keyboard *kb, uint8_t code);
uint8_t KeybScanset3(Keyboard *kb, uint8_t code);
uint8_t KeybUsb2Ansi(Keyboard *kb, char *buf, uint8_t code);
uint8_t KeybReadImm(Keyboard *kb, uint8_t *ch);
uint8_t KeybReadCode(Keyboard *kb, uint8_t *ch);
uint8_t KeybReadUsb(Keyboard *kb);

uint8_t check_parity(uint16_t val);

#endif
/* [] END OF FILE */
