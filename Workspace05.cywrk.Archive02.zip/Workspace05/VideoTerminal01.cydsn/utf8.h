/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef _UTF8_H_
#define _UTF8_H_

#include "project.h"
#include "terminal.h"
uint8_t  ucs2utf8(unsigned char *utf8buf, uint16_t codepoint);
uint8_t  utf8_2ucs(uint16_t *codepoint, Buffer_t in_buffer);
uint8_t  ucs2ansi(uint16_t codepoint);
uint16_t ansi2ucs(unsigned char ch);

#endif
/* [] END OF FILE */
