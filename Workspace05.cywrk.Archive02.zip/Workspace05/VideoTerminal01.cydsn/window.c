/* ========================================
 *
 * Copyright (C) 2022 by Pieter Vandevoorde
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * ========================================
*/

#include "window.h"
#include "screen.h"

extern Screen scrn;

/* Forward Declarations of local functions */
void set_cursor_state(Window *win, uint8_t val);

/*******************************************************************************
* Function Name: windowInit
********************************************************************************
*
*   Summary:   Defines a rectangular text window.
*
*   Parameters:
*      win       Pointer to a Window structure
*      x_orig    Top left corner x coordinate of window
*      y_orig    Top left corner y coordinate of window
*      width     Width in pixels
*      height    Height in pixels
*      fnt       Font to use
*      mode      0 if text window, 1 for graphics window
*
*   Return: none
*
*******************************************************************************/
void WindowInit(Window *win, uint16_t x_orig, uint16_t y_orig, uint16_t width, uint16_t height, ScreenFont *fnt, eCurType curMode) {
    // TODO: check boundaries
    win->orig_x = x_orig;
    win->orig_y = y_orig;
    win->border = 2;
    win->w_x    = width;
    win->w_y    = height;
    win->cursor_type  = curMode;
    
    /* text related */
    win->rotation = 0;
    win->cursor_y   = win->cursor_x   = 0;
    win->textsize_x = win->textsize_y = 1;
    win->fnt    = fnt;
    if (fnt) {
        win->fnt_x  = fnt->width;
        win->fnt_y  = fnt->height;
    } else {
        win->fnt_x  = 6;
        win->fnt_y  = 9;
    }
    win->bb_x = win->fnt_x * win->textsize_x;
    win->bb_y = win->fnt_y * win->textsize_y;
    win->nch_x = width  / win->bb_x;
    win->nch_y = height / win->bb_y;
    win->textcolor   = WHITE;
    win->textbgcolor = BLACK;
    win->wrap_x  = 1;
    win->tabstop = 8;
    win->scroll_up  = SCRL_SCRL;
    win->scroll_dwn = SCRL_SCRL;
    
    WindowStart(win);
}
/*******************************************************************************
* Function Name: WindowStart
********************************************************************************
*
*   Summary:   Makes selected window the active window, draws border and
*              activates cursor blinking.
*
*   Parameters:
*      win       Pointer to a Window structure
*
*   Return: none
*
*******************************************************************************/
void WindowStart(Window *win) {
    // Draw border outside the effective window
    if (win->border) ScreenDrawRect(win->orig_x - win->border, win->orig_y - win->border,
                                    win->w_x + 2 * win->border + 1, win->w_y + 2 * win->border + 1, 1);
    
    scrn.act_win = win; // Needed to blink cursor
}

/*******************************************************************************
* Function Name: windowSetFont
********************************************************************************
*
*   Summary:   Changes the currently set font
*
*   Parameters:
*      win       Pointer to a Window structure
*      fnt       Font to use
*
*   Return: none
*
*******************************************************************************/
void WindowSetFont(Window *win, ScreenFont * fnt) {
    if (win == NULL) return;
    
    win->fnt    = fnt;
    if (fnt) {
        win->fnt_x  = fnt->width;
        win->fnt_y  = fnt->height;
    }
}

/*******************************************************************************
* Function Name: WindowTextSize
********************************************************************************
*
*   Summary:   Multiplies the font with a given factor
*
*   Parameters:
*      win       Pointer to a Window structure
*      size_x    Multiplication in X direction, factor is (size_x + 1)
*      size_y    Multiplication in Y direction, factor is (size_y + 1)
*
*   Return: none
*
********************************************************************************/
void WindowSetTextSize(Window *win, uint8_t size_x, uint8_t size_y) {
    if (size_x < 4) {
        win->textsize_x = size_x + 1;
        win->bb_x = win->textsize_x * win->fnt_x;
        win->nch_x = win->w_x / win->bb_x;
    }
    if (size_y < 3) {
        win->textsize_y = size_y + 1;
        win->bb_y = win->textsize_y * win->fnt_y;
        win->nch_y = win->w_y / win->bb_y;
    }
}

/*******************************************************************************
* Function Name: WindowSetCursor
********************************************************************************
*
*   Summary:   Positions the cursor on the coordinate given. Coordinates are
*              in pixels relative to the origin of the window. The values are
*              checked for being valid.
*
*   Parameters:
*      win       Pointer to a Window structure
*      x         Top left corner x coordinate of cursor
*      y         Top left corner y coordinate of cursor
*
*   Return: none
*
*******************************************************************************/
void WindowSetCursor(Window *win, uint16_t x, uint16_t y) {

    set_cursor_state(win, 0); // Erase cursor

    if (x < win->w_x - win->bb_x) win->cursor_x = x;
    if (y < win->w_y - win->bb_y - 1) win->cursor_y = y;
    
    set_cursor_state(win, 1);
    
}

/*******************************************************************************
* Function Name: WindowSetCursorRel
********************************************************************************
*
*   Summary:   Changes the cursor position relative to the current position.
*              Checks are made that the resultingcursor position is valid.
*
*   Parameters:
*      win       Pointer to a Window structure
*      dx        Horizontal cursor displacement
*      dy        Vertical cursor displacement
*
*   Return: 0 if cursor move is valid
*
*******************************************************************************/
uint8_t WindowSetCursorRel(Window *win, int16_t dx, int16_t dy) {
    int16_t pos_x = win->cursor_x + dx;
    int16_t pos_y = win->cursor_y + dy;
    
    uint8_t result = 0;
    
    // Validate positions
    if (pos_x < 0) return 1;

    if (pos_x > win->w_x - win->bb_x) {
        if (win->wrap_x) {
            pos_x = 0;
        }
        else result = 1;
    }
    
    if (pos_y < 0) {
        if (win->scroll_dwn == SCRL_SCRL) { 
            WindowScroll(win, - win->bb_y);
            pos_y = 0;
        }
        else
        if (win->scroll_dwn == SCRL_WRAP) {
            pos_y = win->w_y - win->bb_y;
        }
        else result = 2;
    } else
    if (pos_y > win->w_y - win->bb_y) {
        if (win->scroll_up & SCRL_SCRL) {
            WindowScroll(win, win->bb_y);
            pos_y -= dy; // Keep position
        } else
        if (win->scroll_up & SCRL_WRAP) {
            pos_y = 0;
        }
        else result = 2;
    }
    
    if (result == 0) {
        set_cursor_state(win, 0); // Erase cursor
        win->cursor_x = pos_x;
        win->cursor_y = pos_y;
        set_cursor_state(win, 1);
    }
    
    return result;
}

/*******************************************************************************
* Function Name: WindowMoveCursor
********************************************************************************
*
*   Summary:    Changes the cursor position relative to the current position
*               count times. Count is the number of characters, not pixels.
*
*   Parameters:
*      win:       Pointer to a Window structure
*      dir:       Direction (up, down, left, right)
*      count:     Number of characters to move cursor.
*
*   Return: none
*
*******************************************************************************/
void WindowMoveCursor(Window *win, eWindir dir, uint8_t count) {
        for (uint8_t i = 0; i < count; i++) {
            switch (dir) {
                case W_LEFT:
                    WindowSetCursorRel(win, -win->bb_x, 0);
                    break;
                case W_RIGHT:
                    WindowSetCursorRel(win, win->bb_x, 0);
                    break;
                case W_UP:
                    WindowSetCursorRel(win, 0, -win->bb_y);
                    break;
                case W_DOWN:
                    WindowSetCursorRel(win, 0, win->bb_y );
                    break;
            }
        }
}

static uint8_t  state = 0; // Cursor 0: off, 1: on
uint8_t toggle = 0;

void set_cursor_state(Window *win, uint8_t val) {
    
    //if (val == 0) WindowBlinkCursor(win, 0); // Erase cursor
    WindowBlinkCursor(win, val);
            
    state = val;
}


/**********************************************************************************
* Function Name: WindowBlinkCursor
***********************************************************************************
*
*   Summary:    This function makes the cursor blink at predetermined intervals.
*               If the second argument is 0 or 1, the cursor is only erased or set.
*               This function uses a global variable scn_mask that is set
*               to 0xffffffff by an interrupt routine that runs with every new
*               videoframe. The current frame rate is 60 frames/second.
*               This function will clear one bit of the mask to indicate that
*               it has executed.
*               if f is 2, the function will decrement a frame counter.
*               If the framecounter reaches zero, the cursor will change state
*               and the framecounter is reloaded.
*        
*
*   Parameters:
*      win:       Pointer to a Window structure
*      f:         Cursur action to perform:
*                 0 -> erase cursor
*                 1 -> set cursor
*                 2 -> toggle cursor
*
*   Return: none
*
**********************************************************************************/
void WindowBlinkCursor(Window *win, uint16_t f) {
    static uint8_t framecount;
    uint8_t y0;     // Cursor start line
    uint8_t pix;    // Cursor end line
    uint8_t ym = win->bb_y - 1;
    
    if (f < 2) {
        framecount = 0;
    } else {
        if ( (scn_mask & 1) == 0) return;
        scn_mask &= ~1;
    }
    
    if (win == NULL) return;
    
    if (win->cursor_type == 0 || state == 0) return;
    
    if (framecount == 0) {
    
        framecount = 40;
    
        y0 = (win->cursor_type == 1) ? ym - 1 : 1; // cursor start line
        
        switch (f) {
            case 0: if (toggle == 0) return;
                break;
            case 1: if (toggle != 0) return;
                break;
        }
            
        toggle = ~toggle;

        for (uint16_t y = y0; y <= ym; y++) {
            for (uint16_t x = 0; x < win->bb_x - 1; x++) {
                pix = ScreenReadPixel(win->orig_x + win->cursor_x + x, win->orig_y + win->cursor_y + y );
                //ScreenTogglePixel(win->orig_x + win->cursor_x + x, win->orig_y + win->cursor_y + y);
                pix = !pix;
                ScreenWritePixel(win->orig_x + win->cursor_x + x, win->orig_y + win->cursor_y + y, pix );
            }
        }
    } else
        framecount--;
    
}

/*******************************************************************************
* Function Name: WindowSetMode
********************************************************************************
*
*   Summary:    Changes the cursor typw
*
*   Parameters:
*      win      Pointer to a Window structure
*      mode     Can be none, underline or block
*
*   Return: none
*
*******************************************************************************/
void WindowSetMode(Window *win, eCurType mode) {
    win->cursor_type = mode;
}

/*******************************************************************************
* Function Name: WindowClear
********************************************************************************
*
*   Summary:    Fills the current window with color given
*
*   Parameters:
*      win      Pointer to a Window structure
*      color    Background color if 0 else foreground color
*
*   Return: none
*
*******************************************************************************/
void WindowClear(Window *win, uint8_t color) {
    ScreenFillRect(win->orig_x, win->orig_y, win->w_x, win->w_y, color);
}

/*******************************************************************************
* Function Name: WindowScroll
********************************************************************************
*
*   Summary:   Scrolls the text upwards <num> pixels if num is positive, scrolls
*              downwards when num is negative. Typically used when the cursor is
*              at the end of the last line of the text window.
*
*   Parameters:
*      win       Pointer to a Window structure
*      num       Number of horizontal lines to scroll (up or down)
*
*   Return: none
*
*******************************************************************************/
void WindowScroll(Window *win, int16_t num) {
    uint8_t  x_rem_left  = win->orig_x & 15;
    uint8_t  x_rem_right = (win->orig_x + win->w_x) & 15;
    uint16_t xl_word = (x_rem_left) ? win->orig_x / 16 + 1 : win->orig_x / 16;
    uint16_t xr_word = (win->orig_x + win->w_x) / 16;
    uint16_t pixdata;
    uint16_t pixmask_l, pixmask_r;

    uint16_t words_x = xr_word - xl_word; // words on same line to copy with memcpy
    
    uint16_t orig = win->orig_y * scrn.scn_wpl + xl_word; // in words, not pixels

    set_cursor_state(win, 0); // Erase cursor

    pixmask_l = 0xffff >> x_rem_left;
    pixmask_r = 0xffff << (16 - x_rem_right);
    
    if (num > 0) {
        if (num > win->w_y) num = win->w_y;
        // move all lines num lines up
        for (int16 y = 0; y < win->w_y - num; y++) {
            if (x_rem_left) {
                pixdata = scrn.scn_pix[orig - 1 + (y + num) * scrn.scn_wpl] & pixmask_l;
                scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] &= ~pixmask_l;
                scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] |= pixdata;
            }
            memcpy(&scrn.scn_pix[orig + y * scrn.scn_wpl],
                   &scrn.scn_pix[orig + (y + num) * scrn.scn_wpl], 2 * words_x);
            if (x_rem_right) {
                pixdata = scrn.scn_pix[orig + words_x + (y + num) * scrn.scn_wpl] & pixmask_r;
                scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
                scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] |= pixdata;
            }
        
        }
    
        // Clear bottom num lines
        for (uint16 y = win->w_y - num; y < win->w_y; y++) {
            if (x_rem_left) scrn.scn_pix[orig - 1 + scrn.scn_wpl * y] &= ~pixmask_l;
            memset(&scrn.scn_pix[orig + scrn.scn_wpl * y], 0, 2 * words_x); // Clear last num lines of the window
            if (x_rem_right) scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
        }
    }
    
    if (num < 0) {
        if (num < -win->w_y) num = -win->w_y;

        for (int16 y = win->w_y; y >= -num; y--) { // move all lines from top num lines down
            if (x_rem_left) {
                pixdata = scrn.scn_pix[orig - 1 + (y + num) * scrn.scn_wpl] & pixmask_l;
                scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] &= ~pixmask_l;
                scrn.scn_pix[orig - 1 + y * scrn.scn_wpl] |= pixdata;
            }
            memcpy(&scrn.scn_pix[orig + y * scrn.scn_wpl],
                   &scrn.scn_pix[orig + (y + num) * scrn.scn_wpl], 2 * words_x);
            if (x_rem_right) {
                pixdata = scrn.scn_pix[orig + words_x + (y + num) * scrn.scn_wpl] & pixmask_r;
                scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
                scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] |= pixdata;
            }
            
        }

        // Clear top num lines
        for (uint16 y = 0; y < -num; y++) {
            if (x_rem_left) scrn.scn_pix[orig - 1 + scrn.scn_wpl * y] &= ~pixmask_l;
            memset(&scrn.scn_pix[orig + scrn.scn_wpl * y], 0, 2 * words_x); // Clear last num lines of the window
            if (x_rem_right) scrn.scn_pix[orig + words_x + y * scrn.scn_wpl] &= ~pixmask_r;
        }
    }
    
    set_cursor_state(win, 1);
}

/*******************************************************************************
* Function Name: WindowShowFont
********************************************************************************
*
* Summary:
*    Displays the selected font table, called by pressing shift F11
*
*******************************************************************************/
void WindowShowFont(Window *win) {
    WindowSetCursor(win, 0, 4 * win->bb_y);
    for (uint16_t ch = 32; ch <= 255; ch++) {
        WindowWrite(win, ch, 0);
        if (ch % 16 == 15) {
            WindowWrite(win, '\r', 0); // carriage return
            WindowWrite(win, '\n', 0); // new line
        }
    }
}

/*******************************************************************************
* Function Name: WindowWrite
********************************************************************************
*
* Summary:
*    Writes a character on the screen at the current cursor position.
*    Advances the cursor and wraps on a new line is required.
*    Scrolls the window one line if the cursor is on the last line
*
* Parameters:
*    win: pointer to the window where we want to write
*    uc:  unicode character to display
*    inv: invert foreground and background colors
*
* Return: none
*
*******************************************************************************/
void WindowWrite(Window *win, uint8_t ac, uint8_t inv) {
    uint16_t new_cursor_y = win->cursor_y;
    uint8_t  adv_y = 0, print_ch = 0;
    uint8_t  pos_x = win->cursor_x / win->bb_x;

    
    switch (ac) {
        case 10:
        case 11:
            adv_y = 1;
            break;
        case 13:
            pos_x = 0;
            break;
        case 8:
        case 127:
            if (pos_x > 0) pos_x--;
            if (ac == 127) print_ch = 1;
            break;
        case 9:
            pos_x += win->tabstop - pos_x % win->tabstop;
            if (pos_x >= win->nch_x)
                pos_x = win->nch_x - 1;
            break;
        default:
            print_ch = 1;
    }
    
    set_cursor_state(win, 0); // Erase cursor

    if (print_ch) { 
        
        ScreenDrawChar(win->orig_x + pos_x * win->bb_x, win->orig_y + new_cursor_y,
            ac, win->fnt, inv ? win->textbgcolor : win->textcolor, inv ? win->textcolor : win->textbgcolor,
            win->textsize_x, win->textsize_y);
        
        if (ac != 0x7f)
            pos_x += 1; // Advance x one char
        
        if (pos_x >= win->nch_x) {
            if (win->wrap_x) {
                pos_x = 0;
                adv_y = 1;
            }
            else {
                pos_x = win->nch_x - 1; // end of line
            }
        }          
    }
    
    if (adv_y) {
        if (new_cursor_y + 2 * win->bb_y <= win->w_y) {
            new_cursor_y += win->bb_y;
        }
        else 
            WindowScroll(win, win->bb_y);
    }
    
    // Update here to avoid cursor jumping around
    win->cursor_x = pos_x * win->bb_x;
    win->cursor_y = new_cursor_y;
    
    set_cursor_state(win, 1);
    
}

/*******************************************************************************
* Function Name: WindowWriteString
********************************************************************************
*
* Summary:
*    Takes a null terminated string and writes it on the screen starting at the
*    current cursor position.
*    Advances the cursor and wraps on a new line is required.
*
* Parameters:
*    win:   Pointer to the window where we want to write
*    str:   String to display
*    inv: invert foreground and background colors												 
*
* Return: none
*
*******************************************************************************/
void WindowWriteString(Window *win, char *str, uint8_t inv) {
    char ch = *str++;
    
    while (ch) {
        WindowWrite(win, ch, inv);
        ch = *str++;
    }
}

/* [] END OF FILE */
