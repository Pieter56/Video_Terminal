/* ===================================================================== *
 *                                                                       *
 * Copyright (C) 2022 by Pieter Vandevoorde                              *
 *                                                                       *
 * This program is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation, either version 3 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 *                                                                       *
 * ===================================================================== *
*/

/* Note
  P0.2 P0.3 P0.4 P3.2 contain bypass capacitor and should not be used unless the capacitor is removed
  P15.0 and P15.1 XTAL
  P15.4 CMOD
  P2.1 LED
  P2.2 SW1

*/
#include "project.h"

#include "screen.h"
#include "window.h"
#include "terminal.h"

/* Video ram containing the pixels on the display */
static uint16_t video_ram[SCREEN_W * SCREEN_H / PIX_PER_WORD] __attribute__ ((aligned(32)));

/* Global for the instances of terminal, keyboad and a text window */
Terminal term1;
Keyboard kb1;
Window   win1;

/*******************************************************************************
* MAIN PROGRAM START
*******************************************************************************/
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    UART_Start();

    ScreenInit(video_ram, SCREEN_W, SCREEN_H, NULL); // Initialise screen and callback
    ScreenClear(0);
    
    /* Initialise keyboard */
    KeybInit(&kb1);
    
    TermInit(&term1, &win1, &kb1); // Initialise the terminal, the window and the keyboard
    
    for(;;)                                      
    {
        TermDispatch(&term1);          // Read a character from the keyboard and process further
        TermReceive(&term1);           // Process data received from serial line
        WindowBlinkCursor(&win1, 2);   // Just blink the cursor if needed
        ScreenFrameAction();           // Optional processing can be added here
    }
}

/* [] END OF FILE */
