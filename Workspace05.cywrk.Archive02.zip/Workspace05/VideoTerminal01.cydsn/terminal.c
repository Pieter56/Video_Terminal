/* ===================================================================== *
 *                                                                       *
 * Copyright (C) 2022 by Pieter Vandevoorde                              *
 *                                                                       *
 * This program is free software: you can redistribute it and/or modify  *
 * it under the terms of the GNU General Public License as published by  *
 * the Free Software Foundation, either version 3 of the License, or     *
 * (at your option) any later version.                                   *
 *                                                                       *
 * This program is distributed in the hope that it will be useful,       *
 * but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 * GNU General Public License for more details.                          *
 *                                                                       *
 * You should have received a copy of the GNU General Public License     *
 * along with this program.  If not, see <http://www.gnu.org/licenses/>. *
 *                                                                       *
 * ===================================================================== *
*/
#include "project.h"

#include "terminal.h"
#include "window.h"
#include "menu.h"
#include "keyboard.h"
#include "utf8.h"

#include "stdio.h"

extern ScreenFont Font7x13;
extern Menu *menu_main_sub[];

/*
 Newline
 Auto Repeat
 Keyboard Layout
 Scanset
 Foreground Color
 Background Color
 Cursor Type
 Text Size X (should add 1)
 Text Size Y (should add 1)
 Wrap Around
 Line local
 Character Set
*/
uint8_t term_setting_initial[] = { 1, 1, 1, 0, WHITE, BLACK, C_UNDERL, 0, 0, 1, 0, 0 }; 

/*******************************************************************************
* Function Name: TermInit
********************************************************************************
*
* Summary:
*  Initialiase the Terminal, Window and Keyboard structures passed as parameters.
*  Use the settings stored in the array term_settings_initial[].
*  
* Parameters:
*  tm:    pointer to a terminal structure
*  win:   pointer to a window structure
*  kb:    pointer to a keyboard structure
*
* Return: None
*
*******************************************************************************/
void TermInit(Terminal *tm, Window *win, Keyboard *kb) {
    uint8_t scanset = 0;
    
    for (uint8_t tsi = 0; tsi < TERM_SETTINGS_NUM; tsi++) {
        tm->term_settings[tsi] = term_setting_initial[tsi];
    }

    ScreenSetColor2(tm->term_settings[FT_FG_COLOR], tm->term_settings[FT_BG_COLOR]);
    
    tm->kb = kb;
    tm->win = win;
    tm->seqMode = ESC_NONE;

    //ScreenDrawRect(200, 200, 10, 10, 1);
    BufferInit(&tm->SerInBuf);
    BufferInit(&tm->SerOutBuf);
    BufferInit(&tm->EscapeBuf);
    
/* SCREEN_W is 640,
   SCREEN_H is 360
    window size x is 560
    window size y is 325
    with 7x13 character, we have:
    80 characters horizontally
    25 characters vertically    
    
*/
    WindowInit(tm->win, 40, 17, SCREEN_W - 80, SCREEN_H - 35, &Font7x13, 1);
    tm->win->wrap_x = tm->term_settings[FT_WRAP];
    //tm->win->scroll_up = tm->term_settings[FT_WRAP];
    //tm->win->scroll_dwn = tm->term_settings[FT_WRAP];
    WindowSetTextSize(tm->win, tm->term_settings[FT_SIZE_X], tm->term_settings[FT_SIZE_Y]);
    
    WindowSetCursor(tm->win, 0, 0);
    
    WindowWriteString(win, "Video Terminal with PS2 keyboard\r\nUse F12 to change configuration", 0);

    KeybSetLayout(kb, tm->term_settings[FT_KB_LAYOUT]);
    
    if (KeybSetScanset(kb, &scanset) != 0) {
        kb->fp_scan = KeybScanset2;
        kb->scanset = 2;
    }
    tm->term_settings[FT_KB_SCANSET] = kb->scanset;
    kb->newline = tm->term_settings[FT_NEWLINE];

}

/*******************************************************************************
* Function Name: TermSetupModify
********************************************************************************
*
* Summary:
*  As result of a menu selection, pass an index to the current parameter and
*  the new value to set. Keeps the new value in the term_settings[] array
*  and calls a function to change the behaviour if needed.
*  Some parameter changes will only become effective when exiting the Setup mode.
*  
* Parameters:
*  tm:    pointer to a terminal structure
*  sel0:  index in tm->term_settings for the parameter to be changed
*  sel1:  new value
*
* Return: None
*
*******************************************************************************/
void TermSetupModify(Terminal *tm, eTerminalFeature sel0, uint8_t sel1) {
    uint8_t curr_val = tm->term_settings[sel0];
    uint8_t newval = sel1;
    uint8_t scanset = 3;
    
    if (curr_val != sel1) {
        tm->term_settings[sel0] = newval;
        
        switch(sel0) {
            case FT_NEWLINE: // auto newline
                tm->kb->newline = newval;
                break;
            case FT_TYPEMATIC: // typematic repeat on/off (only works when using scanset 3)
                KeybSetScanset(tm->kb, &scanset); // First set scanset 3
                tm->term_settings[FT_KB_SCANSET] = tm->kb->scanset;
                KeybSend(tm->kb, newval ? 0xFA : 0xF8);
                break;
            case FT_KB_LAYOUT: // keyboard layout
                KeybSetLayout(tm->kb, newval);
                break;
            case FT_KB_SCANSET: // keyboard scanset
                if (newval != 3) { // Typematic is alway on when using scanset 1 or 2.
                    tm->term_settings[FT_TYPEMATIC] = 1;
                }
                KeybSetScanset(tm->kb, &newval);
                break;
            case FT_FG_COLOR: // foreground color
            case FT_BG_COLOR: // background color
                ScreenSetColor2(tm->term_settings[FT_FG_COLOR], tm->term_settings[FT_BG_COLOR]);
                break;
            case FT_WRAP: // Wrap Around
                tm->win->wrap_x = newval;
                break;
            case FT_SIZE_X: // No extra code needed
            case FT_SIZE_Y: // No extra code needed
            case FT_CURSOR_TYPE: // Cursor type, no extra code needed
            case FT_LOCAL: // Line local (no extra code needed)
            case FT_CHARSET: // No extra code needed
                break;
        }
    }
    
}

/*******************************************************************************
* Function Name: TermSetup
********************************************************************************
*
* Summary:
*  Check the keyboard value passed:
*    - when F12: start terminal Setup mode.
*    - when in Setup mode, use the given character to scroll through the menus.
*  
* Parameters:
*  tm:    pointer to a terminal structure
*  code:  usb code received from the keyboard
*
* Return: None
*
*******************************************************************************/
void TermSetup(Terminal *tm, uint8_t code) {
    static uint8_t main_selection, sub_selection, main_menu_items;
    //uint8_t menu_items;
    Window *win = tm->win;
    
    switch (code) {
        case 69: // F12 - Setup
            WindowSetTextSize(win, 0, 0);
            WindowSetCursor(win, 0, 0);
            WindowSetMode(win, 0); // No cursor
            WindowClear(win, 0);   // erase window to background color
            WindowWriteString(win, "Setup", 0);
            main_selection = 0;
            sub_selection  = 0;
            break;
        case 40: // enter
        case 44: // space
            if (tm->mode == SETUP_MAIN) {
                tm->mode = SETUP_SUB;
                sub_selection = tm->term_settings[main_selection]; // Set current value
            }
            else { // We should now change the selected value
                TermSetupModify(tm, main_selection, sub_selection);
                // Return from submenu
                MenuShowSub(tm, main_selection, sub_selection, 1, 21 * win->bb_x + 3, (main_selection + 1) * win->bb_y); // erase window
                tm->mode = SETUP_MAIN;
            }
            break;
            
        case 81: // down
            if (tm->mode == SETUP_MAIN) {
                if (main_selection < main_menu_items - 1) main_selection++;
            } else {
                if (sub_selection < menu_main_sub[main_selection]->items - 1) sub_selection++;
            }
            break;
            
        case 82: //up
            if (tm->mode == SETUP_MAIN) {
                if (main_selection > 0) main_selection--;
            }
            else {
                if (sub_selection > 0) sub_selection--;
            }
            break;
            
        case 41: // escape
            if (tm->mode == SETUP_MAIN) {
                WindowSetTextSize(win, tm->term_settings[FT_SIZE_X], tm->term_settings[FT_SIZE_Y]);
                WindowSetCursor(win, 0, 0);
                WindowSetMode(win, tm->term_settings[FT_CURSOR_TYPE]);
                WindowClear(win, 0);
                tm->mode = TERMINAL;
                return;
            }
            // Return from submenu
            MenuShowSub(tm, main_selection, sub_selection, 1, 21 * win->bb_x + 3, (main_selection + 1) * win->bb_y); // erase window
            tm->mode = SETUP_MAIN;
            break;
            
            default: ;
    }
    
    if (tm->mode == SETUP_MAIN) {
        main_menu_items = MenuShowMain(tm, main_selection, 0);
    } else {
        MenuShowMain(tm, main_selection, 0);
        MenuShowSub(tm, main_selection, sub_selection, 0, 21 * win->bb_x + 3, (main_selection + 1) * win->bb_y);
    }

    
}

/*******************************************************************************
* Function Name: TermDispatch
********************************************************************************
*
* Summary:
*  Check if a keyboard key is pressed. If so, read the value.
*  Pass the value to the appropriate function, depending on the current mode.
*  
* Parameters:
*  tm:    pointer to a terminal structure
*
* Return: None
*
*******************************************************************************/
void TermDispatch(Terminal *tm) {
    Keyboard *kb = tm->kb;
    uint8_t code;
    
    if (kb->status() & 0x01) {
        code = KeybReadUsb(kb);
        if (code) {
            switch (tm->mode) {
                case TERMINAL:
                    if (code == 69) {
                        tm->mode = SETUP_MAIN;
                        TermSetup(tm, code);
                    } else if ( code == 68 && (kb->keyb_modifiers & (KEY_LEFT_SHIFT | KEY_RIGHT_SHIFT)) ) {
                        WindowShowFont(tm->win);
                    } else
                        TermTransmit(tm, code);
                    break;
                case SETUP_MAIN:
                case SETUP_SUB:
                    TermSetup(tm, code);
                    break;
            }
        }
    }
}


/*******************************************************************************
* Function Name: TermEscapeSeq
********************************************************************************
*
* Summary:
*  Handles a sequence of characters that control cursor movement (ANSI escape sequence)
*  Formats may be:
*   ESC I F1
*   CSI P I F2
*   DCS P I F2 <data string> ST
*
*   ESC is 0x1b
*   CSI is 0x1b [ or 0x9b
*   DCS is 0x1b P or 0x90
*   ST  is 0x9c
*   I: 0x20-0x2f
*   P: 0x30-0x3f
*   F1: 0x30-0x7e
*   F2: 0x40-0x7e
*
* Parameters:
*  tm:  pointer to terminal structure
*  ch:  character received from serial line or internal buffer
*
* Return: 0 if it is a non-printable character or escape sequence
*         1 if the character has to be displayed on screen
*         
*******************************************************************************/
uint8_t TermEscapeSeq(Terminal *tm,  uint8_t ch) {
    uint8_t rval = 1;
    uint8_t count[4];
    int par[4];
    uint8_t parameter;

    if (ch < 0x20 || ch > 127) { // We should not receive a C0 character or character > 127 in escape mode
        tm->seqMode = ESC_NONE;
        BufferInit(&tm->EscapeBuf);
        return 0;
    }

    if (tm->seqMode == ESC_ESC) {
        tm->seqMode = TermCS1(ch + 0x40);
        BufferInit(&tm->EscapeBuf);
        return 0;
    }

    BufferAdd(&tm->EscapeBuf, ch);
    
    if (ch >= 0x40 && ch < 128) { // Final byte
        uint8_t *cp = tm->EscapeBuf.buff;
        
        parameter = 0;
        par[0] = par[1] = par[2] = par[3] = 0;
        
        // Process Parameter bytes if any
        while (*cp <= 0x3f && *cp >= 0x30) {
            if (*cp >= '0' && *cp <= '9' ) {
                par[parameter] = 10 * par[parameter] + ( *cp - '0' );
            } else
            if (*cp == ';') parameter++;

            cp++;
        }
        for (uint8_t k = 0; k < 4; k++) {
            if (par[k] == 0)
                count[k] = 1;
            else
            count[k] = par[k];
        }
        // Process Intermediate bytes if any
        while (*cp <= 0x2f) {
            cp++;
        }
        
        Window *win = tm->win;
                    
        switch (ch) {
            case 'H' : 
                WindowSetCursor(win, (count[0] - 1) * win->fnt_x * win->textsize_x,
                        (count[1] - 1) * win->fnt_y * win->textsize_y);
                break;
            case 'A' : 
                WindowMoveCursor(win, W_UP, count[0]);
                break;
            case 'B':
                WindowMoveCursor(win, W_DOWN, count[0]);
                break;
            case 'C':
                WindowMoveCursor(win, W_RIGHT, count[0]);
                break;
            case 'D':
                WindowMoveCursor(win, W_LEFT, count[0]);
                break;
            case 'J':
                switch (par[0]) {
                    case 0: // From cursor till bottom of window
                        ScreenFillRect(win->orig_x + win->cursor_x, win->orig_y + win->cursor_y,
                                   win->w_x - win->cursor_x, win->fnt_y * win->textsize_y, 0);
                        ScreenFillRect(win->orig_x, win->orig_y + win->cursor_y + win->fnt_y * win->textsize_y,
                                   win->w_x, win->w_y - (win->cursor_y + win->fnt_y * win->textsize_y) , 0);
                        break;
                    case 1: // From cursor till top of window
                        ScreenFillRect(win->orig_x, win->orig_y + win->cursor_y,
                           win->cursor_x + win->fnt_x * win->textsize_x, win->fnt_y * win->textsize_y, 0);
                        ScreenFillRect(win->orig_x, win->orig_y,
                                   win->w_x, win->cursor_y, 0);
                        break;
                    case 2: // Entire window
                    case 3:
                        WindowClear(win, 0);
                        break;
                }
                break;
            case 'K': // erase till end of line
                if (par[0] == 0) // erase till end of line
                    ScreenFillRect(win->orig_x + win->cursor_x, win->orig_y + win->cursor_y,
                                   win->w_x - win->cursor_x, win->fnt_y * win->textsize_y, 0);
                else
                if (par[0] == 1) // erase till start of line
                    ScreenFillRect(win->orig_x, win->orig_y + win->cursor_y,
                        win->cursor_x + win->fnt_x * win->textsize_x, win->fnt_y * win->textsize_y, 0);
                else
                if (par[0] == 2) // erase till whole line
                    ScreenFillRect(win->orig_x, win->orig_y + win->cursor_y,
                                   win->w_x, win->fnt_y * win->textsize_y, 0);
                break;
            case 'S':
                    WindowScroll(win, count[0] * win->fnt_y * win->textsize_y);
                    break;
            case 'T':
                    WindowScroll(win, - count[0] * win->fnt_y * win->textsize_y);
                    break;
            case 'm': // Cursor and Color commands
                if (par[0] == 0) { // Default settings
                    ScreenSetColor2(tm->term_settings[FT_FG_COLOR], tm->term_settings[FT_BG_COLOR]);
                }
                else
                if (par[0] == 7) { // Reverse video
                    ScreenSetColor2(tm->term_settings[FT_BG_COLOR], tm->term_settings[FT_FG_COLOR]);
                }
                break;
            case '~':
                if (par[0] == 1) WindowSetCursor(win, 0, 0);
                break;
        }
        BufferInit(&tm->EscapeBuf);
        tm->seqMode = ESC_NONE;
    }
    
    return rval;
}

/*******************************************************************************
* Function Name: BufferInit
********************************************************************************
*
* Summary:
*  Utility function to initialise structure of Buffer_t type.
*  
* Parameters:
*  cb:    pointer to a character buffer structure
*
* Return: None
*
*******************************************************************************/
void BufferInit(Buffer_t *cb) {
    cb->count = 0;
    cb->maxlen = MAX_COUNT;
}

/*******************************************************************************
* Function Name: BufferAdd
********************************************************************************
*
* Summary:
*  Utility function to add data to the character buffer.
*  
* Parameters:
*  cb:    pointer to a character buffer structure
*  data:  value to store (unsigned char).
*
* Return: 0 if operation succeeded.
*         1 if the buffer is full.
*
*******************************************************************************/
int BufferAdd(Buffer_t *cb, uint8_t data) {
    
    if (cb->count < cb->maxlen) {
        cb->buff[cb->count++] = data;
        return 0;
    }
    return 1; // Buffer is full
}

/*******************************************************************************
* Function Name: TermCS1
********************************************************************************
*
* Summary:
*  Check the character following Escape and set the corresponding escape mode
*  Currently, only CSI escape mode is handled (ESC followed by [ )
*  Input characters, is character + 0x40
*  
* Parameters:
*  ch:    character indication escape mode
*
* Return: None
*
*******************************************************************************/
escMode TermCS1(uint8_t ch){
    switch (ch) {
        case 0x8E: return ESC_SS2;
        case 0x8F: return ESC_SS3;
        case 0x90: return ESC_DCS;
        case 0x9B: return ESC_CSI;
        case 0x9C: return ESC_ST;
        case 0x9E: return ESC_OSC;
        default:   return ESC_NONE;
    }
}

/*******************************************************************************
* Function Name: TermReadUTF8
********************************************************************************
*
* Summary:
*  Convert UTF-8 data in buffer into a character and display it.
*  
* Parameters:
*  tm:    pointer to Terminal structure
*
* Return: None
*
*******************************************************************************/
void TermReadUTF8(Terminal *tm) {
    uint16_t codepoint;
    uint8_t  val;
    uint8_t  ch;
    
    val = utf8_2ucs(&codepoint, tm->SerInBuf);
    
    if (val > 0) {
        tm->SerInBuf.count = 0;
        ch = ucs2ansi(codepoint);
        WindowWrite(tm->win, ch, 0);
    }
}

/*******************************************************************************
* Function Name: TermTransmit
********************************************************************************
*
* Summary:
*  Handle the usb code passed to this function:
*  - convert the code into one or more characters
*  - send them over the serial line or put them in a buffer, when in local mode
*  
* Parameters:
*  tm:    pointer to Terminal structure
*  code:  usb code received from keyboard
*
* Return: None
*
*******************************************************************************/
void TermTransmit(Terminal *tm, uint8_t code) {
    uint8_t num_ch;
    uint8_t *cp = tm->SerOutBuf.buff;
   
    num_ch = KeybUsb2Ansi(tm->kb, tm->keyb_buf, code);
    
    if (num_ch > 0) {
        uint8_t num_tot = 0;
        uint8_t num_utf = 0;
        unsigned char ch;
        uint16_t ucs;
        
        switch (tm->term_settings[FT_CHARSET]) {
        case CS_UTF_8:
            for (uint8_t i=0; i < num_ch; i++) {
                ch = tm->keyb_buf[i];
                ucs = ansi2ucs(ch);
                num_utf = ucs2utf8(cp, ucs);
                cp += num_utf;
                num_tot += num_utf;
            }
            break;
        case CS_WIN1252:
        case CS_ISO_8859_1:
            strncpy((char *)cp, tm->keyb_buf, num_ch);
            num_tot = num_ch;
            break;
        }
        
        tm->SerOutBuf.count = num_tot; // Adjust character count
        if (! tm->term_settings[FT_LOCAL]) {
            UART_PutArray(tm->SerOutBuf.buff, num_tot);
            BufferInit(&tm->SerOutBuf);
        }
    }
    
}

/*******************************************************************************
* Function Name: TermReceive
********************************************************************************
*
* Summary:
*  Read a character from the serial line or from the internal buffer when in 
*  local mode.
*  When data was received, send it to the display.
*  
* Parameters:
*  pointer to Terminal structure
*
* Return: None
*
*******************************************************************************/
void TermReceive(Terminal *tm) {
    uint8_t ch;
    
    if (tm->term_settings[FT_LOCAL]) {
        uint8_t ch_cnt = tm->SerOutBuf.count;
        for (uint8_t i = 0; i < ch_cnt; i++) {
            TermDisplay(tm, tm->SerOutBuf.buff[i]);
        }
        BufferInit(&tm->SerOutBuf);
    } else {
        ch = UART_GetChar();
        if (ch > 0)
            TermDisplay(tm, ch);
    }
}

/*******************************************************************************
* Function Name: TermDisplay
********************************************************************************
*
* Summary:
*  Process the received character according to the current terminal settings
*  and send it to the display. Also handle escape sequences.
*  
* Parameters:
*  tm:  pointer to Terminal structure
*  ch:  character to be displayed
*
* Return: None
*
*******************************************************************************/
void TermDisplay(Terminal *tm, uint8_t ch) {

    eCharacterSet charSet = tm->term_settings[FT_CHARSET];
    
    if (tm->seqMode == ESC_NONE) {
        if (ch == 0x1b) {
            tm->seqMode = ESC_ESC;
            BufferInit(&tm->EscapeBuf);
            return;
        } else
        if (charSet == CS_WIN1252) {
            WindowWrite(tm->win, ch, 0);
        } else
        if (charSet == CS_ISO_8859_1) {
            if (ch > 128 && ch < 160) {
                tm->seqMode = TermCS1(ch);
                BufferInit(&tm->EscapeBuf);
            }
            else WindowWrite(tm->win, ch, 0);
        } else
        if (charSet == CS_UTF_8) {
            uint16_t codepoint;
            uint8_t  val;
            
            BufferAdd(&tm->SerInBuf, ch);
            val = utf8_2ucs(&codepoint, tm->SerInBuf);
            if (val > 0) {
                tm->SerInBuf.count = 0;
                if (codepoint >= 128 && codepoint < 160) { // C1 control code
                    BufferInit(&tm->EscapeBuf);
                    tm->seqMode = TermCS1(codepoint & 0xff);
                } else {
                    ch = ucs2ansi(codepoint);
                    if (ch > 0) WindowWrite(tm->win, ch, 0);
                }
            }
        }
    } else { // Escape Mode
        TermEscapeSeq(tm, ch);
    }
}

/* [] END OF FILE */
